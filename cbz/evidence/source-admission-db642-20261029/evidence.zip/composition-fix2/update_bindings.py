from pathlib import Path
import json,hashlib,runpy,subprocess
R=Path('/workspace/scratch/db6428847655/cbz/worktrees/math-composition')
p=R/'tests/run_source_admission_mutations.py'; s=p.read_text()
s=s.replace('Fifteen bounded source checker mutations','Sixteen bounded source checker mutations')
anchor='\n\ndef replace_anchor(source, old, new):\n'
old="    raw_lines, code_lines = text.split('\\n'), code.split('\\n')\n    require(len(raw_lines) == len(code_lines), 'unsupported physical-line correspondence')\n    lines = [raw + '\\n' for raw, line in zip(raw_lines, code_lines, strict=True) if DECL.match(line)]"
new="    lines = [raw + '\\n' for raw, line in zip(text.splitlines(), code.splitlines()) if DECL.match(line)]"
case=('helper-declaration-physical-line-alignment-regression','tools/lean_packet_admission.py',old,new,['-m','unittest','discover','-s','tests','-p','test_lean_packet_admission.py','-k','physical_header','-v'])
addition='\nMUTATIONS.append('+repr(case)+')\n'
if s.count(anchor)!=1:raise SystemExit('mutation insertion anchor')
p.write_text(s.replace(anchor,addition+anchor))
p=R/'tests/test_source_admission_mutations.py'; s=p.read_text().replace('len(runner.MUTATIONS), 15','len(runner.MUTATIONS), 16').replace('len(set(names)), 18','len(set(names)), 19'); p.write_text(s)
for rel in ['tools/LEAN_PACKET_ADMISSION.md','frontiers/determinant_moment_20261025/README.md','frontiers/cap_first_exit_lean_20261002/README.md']:
 p=R/rel;s=p.read_text().replace('plus the declaration-header binding removal (fifteen total)', 'plus declaration-header binding removal and physical-line alignment regression (sixteen total)').replace('fifteen-mutation','sixteen-mutation').replace('retains all fourteen old mutants and adds header-guard\nremoval: fifteen mutants', 'retains all fifteen old mutants and adds physical-line alignment\nregression: sixteen mutants')
 s+='\nPhysical-line correction: LF (`\\n`) is the line separator throughout the lexical\ncode census, continuation and declaration-header traversal. Raw and lexed rows\nare paired with an explicit equal-count check and strict zip; Unicode separators\ninside comments or literals cannot shift or silently truncate that pairing.\nBenign comment/string fixtures check exact selected header bytes and harmless\ndefinition-value changes. Existing reviewed packet source and all admission\nbindings remain unchanged. The sixteenth mutant reintroduces the old divergent\n`splitlines()` pairing and is exercised only against these benign fixtures.\n'
 p.write_text(s)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
helper=runpy.run_path(str(R/'tools/lean_packet_admission.py'))
for rel in ['frontiers/determinant_moment_20261025/manifest.json','frontiers/cap_first_exit_lean_20261002/MANIFEST.json']:
 p=R/rel;d=json.loads(p.read_text());d['source_admission']['helper_sha256']=sha(R/'tools/lean_packet_admission.py')
 if isinstance(d['files'],dict):
  for name in d['files']:d['files'][name]=sha(p.parent/name)
 else:
  for entry in d['files']:
   b=(p.parent/entry['path']).read_bytes();entry.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 for module,expected in d['source_admission']['declarations'].items():
  text=(p.parent/(module.replace('.','/')+'.lean')).read_text()
  if helper['declaration_binding'](text)!=expected:raise SystemExit('existing header binding changed '+module)
  if helper['continuation_binding'](text)!=d['source_admission']['continuations'][module]:raise SystemExit('existing continuation binding changed '+module)
 p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
p=R/'tools/lean_packet_admission.registry.json'; d=json.loads(p.read_text())
for rel in d['files']:d['files'][rel]=sha(R/rel)
d['source_mutation_cases']=16
p.write_text(json.dumps(d,indent=2)+'\n')
print('Added one benign alignment mutant; all existing header/continuation bindings preserved.')
