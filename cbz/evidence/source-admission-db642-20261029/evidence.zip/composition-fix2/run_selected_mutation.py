from pathlib import Path
import runpy,json,datetime
R=Path('/workspace/scratch/db6428847655/cbz/worktrees/math-composition');O=Path(__file__).resolve().parent/'selected-mutation'
g=runpy.run_path(str(R/'tests/run_source_admission_mutations.py'));g['prepare_output'](O)
cases=[c for c in g['MUTATIONS'] if c[0]=='helper-declaration-physical-line-alignment-regression']
if len(cases)!=1:raise SystemExit('expected exactly one selected case')
records=[]
for opt in (False,True):
 rec=g['run_case'](cases[0],opt,O);records.append(rec)
 (O/'mutation-summary.json').write_text(json.dumps(records,indent=2)+'\n')
 print(rec['name'],opt,rec['passed'],flush=True)
 if not rec['passed']:raise SystemExit(1)
print('ONLY the new benign physical-line mutation was executed; no complete 16-case campaign claimed.')
