from pathlib import Path
import datetime,hashlib,json,subprocess,time
R=Path('/workspace/scratch/db6428847655/cbz/worktrees/math-composition'); O=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).splitlines()
(O/'source-before-validation.json').write_text(json.dumps({p:sha(R/p) for p in paths},indent=2)+'\n')
records=[]
def run(label,argv,marker):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic();p=subprocess.run(argv,cwd=R,capture_output=True,text=True,timeout=300)
 text=p.stdout+p.stderr;log=O/(label+'.log');log.write_text(text)
 ok=p.returncode==0 and marker in text
 records.append(dict(label=label,argv=argv,cwd=str(R),started_utc=start,seconds=round(time.monotonic()-t,3),exit_code=p.returncode,passed=ok,log=log.name,sha256=sha(log)))
 (O/'execution-summary.json').write_text(json.dumps(records,indent=2)+'\n');print(label,p.returncode,ok,flush=True)
 if not ok:raise SystemExit(1)
for opt in (False,True):
 mode='optimized' if opt else 'normal';py=['python','-B']+(['-O'] if opt else [])+['-S']
 for name,directory,pattern in [('helper','tests','test_lean_packet_admission.py'),('determinant','frontiers/determinant_moment_20261025/tests','test_*.py'),('cap','frontiers/cap_first_exit_lean_20261002','test_*.py')]:
  run(name+'-'+mode,py+['-m','unittest','discover','-s',directory,'-p',pattern,'-v'],'\nOK\n')
 run('runner-matrix-count-'+mode,py+['-m','unittest','discover','-s','tests','-p','test_source_admission_mutations.py','-k','all_named','-v'],'\nOK\n')
 run('source-determinant-'+mode,py+['-c',"import runpy; g=runpy.run_path('frontiers/determinant_moment_20261025/gate.py'); _,d=g['source_check'](); print('SOURCE_ONLY_IDENTITY_PASS: '+d)"],'SOURCE_ONLY_IDENTITY_PASS')
 run('source-cap-'+mode,py+['frontiers/cap_first_exit_lean_20261002/gate.py'],'source_check')
