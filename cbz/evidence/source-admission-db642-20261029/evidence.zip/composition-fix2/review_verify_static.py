from pathlib import Path
from datetime import datetime, timezone
import ast, hashlib, json, os, re, subprocess
R=Path('/workspace/scratch/db6428847655/cbz/worktrees/math-composition')
E=Path('/workspace/scratch/db6428847655/cbz/implementation/math-admission/composition-fix2')
OLD=E.parent/'composition-fix'
BASE='60f9912a2dacfc780bb9219482f694e89975a207'; HEAD='5591b44e1f19846b2b6aa44664a902e2c7963340'
def require(c,m):
 if not c: raise ValueError(m)
def git(*a): return subprocess.check_output(['git','--no-optional-locks','-C',str(R),*a],env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
def blob(rev,p): return git('show',rev+':'+p)
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p): return json.loads(p.read_text())
def log(record,folder):
 b=(folder/record['log']).read_bytes(); require(sha(b)==record['sha256'],'digest '+record['log']); return b.decode()
def phase(text,n):
 xs=re.findall(r'^SOURCE_MUTATION_PHASES\|(.+)$',text,re.M);require(len(xs)==1,'one phase record')
 x=json.loads(xs[0]); require(len(x['tests'])==n and len({t['id'] for t in x['tests']})==n,'phase discovery')
 require(all(t['body_entered'] is True for t in x['tests']),'body entries');return x['events']
commit=read(E/'commit.json');require(git('rev-parse','HEAD').decode().strip()==HEAD,'head')
require(git('rev-parse','HEAD^{tree}').decode().strip()==commit['tree'],'tree')
require(git('rev-parse','HEAD^').decode().strip()==BASE,'parent')
for p,h in commit['source_sha256'].items():require(sha((R/p).read_bytes())==h==sha(blob(HEAD,p)),'committed/current '+p)
executions=read(E/'execution-summary.json');require(len(executions)==12,'execution count');counts={}
for item in executions:
 text=log(item,E);require(item['exit_code']==0,'execution exit');ns=re.findall(r'^Ran (\d+) tests? in ',text,re.M)
 if not item['label'].startswith('source-'):
  expected=20 if item['label'].startswith('helper-') else 117 if item['label'].startswith('determinant-') else 45 if item['label'].startswith('cap-') else 1
  require(ns==[str(expected)] and re.search(r'^OK$',text,re.M) and not re.search(r'^(ERROR|FAILED)',text,re.M),'discovery/pass')
 counts[item['label']]=ns
matrix=read(E/'mutations/mutation-summary.json');require(len(matrix)==38,'matrix size')
keys=[(x['name'],x['optimized']) for x in matrix]; require(len(set(keys))==38,'matrix duplicates')
names={x['name'] for x in matrix}; require(len(names)==19 and all((n,m) in keys for n in names for m in [False,True]),'matrix completeness')
kills=controls=0
for item in matrix:
 for entry in [item['baseline'],item]:
  text=log(entry,E/'mutations');require(re.findall(r'^Ran (\d+) tests? in ',text,re.M)==[str(entry['collected'])] and entry['collected']>0,'positive discovery')
  events=phase(text,entry['collected']);require(not re.search(r'^ERROR:',text,re.M),'no errors')
  if entry is item and not item['control']:
   fs=re.findall(r'^FAIL: test_',text,re.M)
   require(entry['exit_code']!=0 and fs and 'AssertionError:' in text,'assertion failure')
   require(re.search(r'^FAILED \(failures='+str(len(fs))+r'\)$',text,re.M),'summary')
   require(len(events)==len(fs) and all(e['phase']=='body' and e['kind']=='failure' for e in events),'body failures only');kills+=1
  else: require(entry['exit_code']==0 and not events and re.search(r'^OK$',text,re.M),'clean control/baseline')
 require(item['collected']==item['baseline']['collected'],'matching discovery')
 if item['control']:controls+=1
runner='tests/run_source_admission_mutations.py'
def functions(b):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(b).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
require(functions(blob(BASE,runner))==functions((R/runner).read_bytes()),'all runner functions unchanged')
probes=read(OLD/'lifecycle-probes.json');lifecycle_logs=0
for item in probes:
 if 'log' in item:log(item,OLD);lifecycle_logs+=1
 if item['name'] in {'setup','teardown','cleanup','custom_teardown','body_error','empty','timeout'}:
  require(item['killed'] is False and item['control_pass'] is False,'fixture rejection')
# Prior full ten-test run is evidence of unchanged lifecycle methods, not a new run.
old_exec=read(OLD/'execution-summary.json')
for item in old_exec:
 if item['label'] in {'runner-normal','runner-optimized'}:
  text=log(item,OLD);require(re.search(r'^Ran 10 tests in ',text,re.M) and re.search(r'^OK$',text,re.M),'prior runner suite')
protected=read(OLD/'proof-preservation.json')
for item in protected['files']:require((R/item['path']).read_bytes()==blob(protected['base'],item['path']),'protected '+item['path'])
require(len(protected['files'])==95,'95 protected')
for p in ['frontiers/determinant_moment_20261025/manifest.json','frontiers/cap_first_exit_lean_20261002/MANIFEST.json']:
 current=read(R/p); prior=json.loads(blob(BASE,p));require(current['targets']==prior['targets'],'public targets')
 for key in ['census','continuations','declarations']:require(current['source_admission'][key]==prior['source_admission'][key],'admission '+key)
 if 'compiled_inventory' in current:require(current['compiled_inventory'] is None and current['compiled_inventory']==prior['compiled_inventory'],'null inventory')
registry=read(R/'tools/lean_packet_admission.registry.json');require(all(sha((R/p).read_bytes())==h for p,h in registry['files'].items()),'registry')
red=(E/'red-benign-physical-lines.log').read_text();green=(E/'green-benign-physical-lines.log').read_text()
require(re.search(r'^FAILED \(failures=29\)$',red,re.M) and len(re.findall(r'^FAIL:',red,re.M))==29,'29 RED failures')
require(re.search(r'^Ran 2 tests in ',green,re.M) and re.search(r'^OK$',green,re.M),'benign GREEN')
result={'verified_utc':datetime.now(timezone.utc).isoformat(),'head':HEAD,'tree':commit['tree'],'changed_blobs':10,'execution_logs':12,'counts':counts,'mutation_rows':38,'mutation_log_hashes':76,'body_assertion_kills':kills,'controls':controls,'positive_baselines':38,'unchanged_runner_function_ASTs':True,'prior_lifecycle_log_hashes':lifecycle_logs,'prior_full_runner_logs':2,'protected_bytes_verified':95,'reviewed_admission_bindings_unchanged':True,'registry_hashes_match':True,'red_assertion_failures':29,'benign_green_tests':2,'source_or_test_execution':False,'injected_command_experiments':False}
(E/'review-evidence-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
