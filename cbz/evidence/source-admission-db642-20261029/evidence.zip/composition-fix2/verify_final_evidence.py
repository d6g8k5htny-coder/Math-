from pathlib import Path
import ast,datetime,hashlib,json,runpy,subprocess,re
R=Path('/workspace/scratch/db6428847655/cbz/worktrees/math-composition');O=Path(__file__).resolve().parent
BASE='60f9912a2dacfc780bb9219482f694e89975a207';PUB='74565f013575b7b05ecfc4034cd5d638ee355353'
def need(b,m):
 if not b:raise SystemExit(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def prior(c,p):return subprocess.check_output(['git','show',c+':'+p],cwd=R)
source=json.loads((O/'source-before-validation.json').read_text());need(all(sha(R/p)==h for p,h in source.items()),'source drift during verification')
reg=json.loads((R/'tools/lean_packet_admission.registry.json').read_text());need(all(sha(R/p)==h for p,h in reg['files'].items()),'registry mismatch')
execs=json.loads((O/'execution-summary.json').read_text());need(len(execs)==12,'incomplete source validation')
need(all(x['passed'] and x['exit_code']==0 and sha(O/x['log'])==x['sha256'] for x in execs),'execution mismatch')
counts={x['label']:re.findall(r'^Ran (\d+) tests? in ',(O/x['log']).read_text(),re.M) for x in execs}
for mode in ('normal','optimized'):
 for k,n in [('helper','20'),('determinant','117'),('cap','45'),('runner-matrix-count','1')]:need(counts[k+'-'+mode]==[n],'test count mismatch '+k)
m=json.loads((O/'mutations/mutation-summary.json').read_text());need(len(m)==38,'incomplete mutation matrix')
need(len({(x['name'],x['optimized']) for x in m})==38,'duplicate mutation rows')
need(all(x['passed'] and x['baseline']['control_pass'] and x['baseline']['collected']>0 and sha(O/'mutations'/x['log'])==x['sha256'] and sha(O/'mutations'/x['baseline']['log'])==x['baseline']['sha256'] for x in m),'matrix evidence mismatch')
need(sum(x['killed'] for x in m)==32 and sum(x['control'] and x['control_pass'] for x in m)==6,'matrix outcome mismatch')
g=runpy.run_path(str(R/'tests/run_source_admission_mutations.py'));need(g['complete'](m),'runner completeness rejection')
old={'__name__':'previous_runner','__file__':str(R/'tests/run_source_admission_mutations.py')};exec(compile(prior(BASE,'tests/run_source_admission_mutations.py'),'previous-runner','exec'),old)
need(g['MUTATIONS'][:15]==old['MUTATIONS'],'old mutation definitions changed')
def funcs(data):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(data).body if isinstance(n,ast.FunctionDef)}
need(funcs(prior(BASE,'tests/run_source_admission_mutations.py'))==funcs((R/'tests/run_source_admission_mutations.py').read_text()),'runner behavior changed')
protected=json.loads((O.parent/'composition-fix/proof-preservation.json').read_text());need(len(protected['files'])==95,'protected count')
need(all(sha(R/x['path'])==x['base_sha256']==hashlib.sha256(prior(protected['base'],x['path'])).hexdigest() for x in protected['files']),'protected bytes changed')
helper=runpy.run_path(str(R/'tools/lean_packet_admission.py'));manifest_results={}
for name,rel in [('determinant','frontiers/determinant_moment_20261025/manifest.json'),('cap','frontiers/cap_first_exit_lean_20261002/MANIFEST.json')]:
 p=R/rel;now=json.loads(p.read_text());oldm=json.loads(prior(BASE,rel))
 need({k:v for k,v in now.items() if k not in ('files','source_admission')}=={k:v for k,v in oldm.items() if k not in ('files','source_admission')},'manifest semantics changed')
 need({k:v for k,v in now['source_admission'].items() if k!='helper_sha256'}=={k:v for k,v in oldm['source_admission'].items() if k!='helper_sha256'},'admission bindings changed')
 need(now['source_admission']['helper_sha256']==sha(R/'tools/lean_packet_admission.py'),'helper hash mismatch')
 for module,binding in now['source_admission']['declarations'].items():
  text=(p.parent/(module.replace('.','/')+'.lean')).read_text()
  need(helper['declaration_binding'](text)==binding,'current header binding mismatch')
  need(helper['continuation_binding'](text)==now['source_admission']['continuations'][module],'current continuation mismatch')
 manifest_results[name]={'targets':len(now['targets']),'census':len(now['source_admission']['census']),'reviewed_admission_bindings_unchanged':True}
f='frontiers/determinant_moment_20261025/gate.py'; a,b=funcs(prior(PUB,f)),funcs((R/f).read_text()); names=['compiled_implementation','compiled_contract','audit_compiled','invalidate_active_receipt','execute','main'];need(all(a[n]==b[n] for n in names),'compiled gate changed')
f='frontiers/determinant_moment_20261025/compiled_inventory.py';need(prior(PUB,f)==(R/f).read_bytes(),'compiled helper changed')
result=dict(verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),review_base=BASE,source_sha256=source,source_unchanged_during_verification=True,execution_commands=12,test_counts=counts,mutation_rows=38,body_assertion_kills=32,full_suite_controls=6,positive_baselines=38,mutation_log_hashes_checked=76,old_15_mutation_definitions_unchanged=True,runner_function_asts_unchanged=True,protected_files_byte_equal=95,manifests=manifest_results,published_compiled_functions_unchanged=names,published_compiled_helper_unchanged=True,actual_lean='NOT_RUN',compiled_qualification='UNQUALIFIED')
(O/'final-evidence-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='source_sha256'},indent=2))
