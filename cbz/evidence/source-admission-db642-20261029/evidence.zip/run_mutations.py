"""Isolated checker-removal experiments, fresh copies, exact test selection, both modes."""
from pathlib import Path
import subprocess, shutil, tempfile, hashlib, json, datetime
ROOT=Path('/workspace/scratch/db6428847655/cbz/worktrees/math-cbz')
OUT=Path(__file__).resolve().parent
DETP='frontiers/determinant_moment_20261025'
CAPP='frontiers/cap_first_exit_lean_20261002'
helper='tools/lean_packet_admission.py'
shared=['-m','unittest','discover','-s','tests','-p','test_lean_packet_admission.py','-v']
mutants=[
 ('helper-forbidden-token-removal',helper,"    require(not bad, 'forbidden token in source module ' + module + ': ' + repr(sorted(bad)))","    pass  # MUTANT: remove forbidden-token refusal",shared),
 ('helper-census-equality-removal',helper,"    require(actual == expected, 'source declaration census mismatch')","    pass  # MUTANT: remove exact census comparison",shared),
]
for prefix,packet in [('determinant',DETP),('cap',CAPP)]:
 gate=packet+'/gate.py'
 check=("    admission['check_census'](source_census, m['source_admission']['census'])" if prefix=='determinant' else "    admission['check_census'](source_census, m['source_admission']['census'])")
 testdir=packet+('/tests' if prefix=='determinant' else '')
 mutants.append((prefix+'-census-adapter-removal',gate,check,'    pass  # MUTANT: adapter skips census', ['-m','unittest','discover','-s',testdir,'-p','test_gate.py','-k','digest_rebound_omitted','-v']))
 mutants.append((prefix+'-helper-integrity-removal',gate,"    require(sha(data) == digest, 'admission helper hash mismatch')",'    pass  # MUTANT: execute unverified helper',shared))
 mutants.append((prefix+'-helper-symlink-removal',gate,"    require(all(not part.is_symlink() for part in (helper, *helper.parents)),\n            'symlink admission helper')",'    pass  # MUTANT: accept helper symlinks',shared))
records=[]
for name,path,old,new,args in mutants:
 for optimized in [False,True]:
  with tempfile.TemporaryDirectory(prefix='cbz-checker-mutant-') as temp:
   root=Path(temp)
   for packet in [DETP,CAPP]:shutil.copytree(ROOT/packet,root/packet,ignore=shutil.ignore_patterns('.lake','__pycache__'))
   (root/'tools').mkdir();shutil.copy2(ROOT/helper,root/helper)
   (root/'tests').mkdir();shutil.copy2(ROOT/'tests/test_lean_packet_admission.py',root/'tests/test_lean_packet_admission.py')
   # Cap fixture expects its two already-pinned source files in the throwaway repo.
   manifest=json.loads((ROOT/CAPP/'MANIFEST.json').read_text())
   for pin in manifest['pins_on_main']:
    dst=root/pin['path'];dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/pin['path'],dst)
   source=(root/path).read_text()
   if source.count(old)!=1:raise RuntimeError('mutation anchor not unique: '+name)
   (root/path).write_text(source.replace(old,new))
   argv=['python','-B']+(['-O'] if optimized else [])+['-S']+args
   proc=subprocess.run(argv,cwd=root,capture_output=True,text=True,timeout=180)
   label=name+('-optimized' if optimized else '-normal');log=OUT/(label+'.log');log.write_text(proc.stdout+proc.stderr)
   # A killed mutant must have actual assertion failures, not setup errors or zero tests.
   killed=proc.returncode!=0 and 'FAIL:' in proc.stderr and 'Ran 0 tests' not in proc.stderr and 'ERROR:' not in proc.stderr
   records.append(dict(mutant=name,optimized=optimized,argv=argv,exit_code=proc.returncode,killed=killed,log=log.name,sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
   (OUT/'mutation-summary.json').write_text(json.dumps(records,indent=2)+'\n')
   print(label,'KILLED' if killed else 'NOT_QUALIFIED',flush=True)
