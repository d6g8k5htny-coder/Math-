"""Read-only composition review probes; temporary copies only, no package Lean claim."""
import hashlib
import io
import json
from pathlib import Path
import runpy
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path('/workspace/scratch/db6428847655/cbz/worktrees/math-composition')
packet = ROOT / 'frontiers/cap_first_exit_lean_20261002'
gate = runpy.run_path(str(packet / 'gate.py'))
admission = runpy.run_path(str(ROOT / 'tools/lean_packet_admission.py'))
runner = runpy.run_path(str(ROOT / 'tests/run_source_admission_mutations.py'))
anchor = 'theorem toy_frontier : frontier (Icc (-2 : ℝ) 1) = {-2, 1} := frontier_Icc (by norm_num)'
tails = [' register_option cbzHidden : Bool := { defValue := false, descr := "review" }',
         ' newUnknownCommand cbz']
observations = []
for tail in tails:
    with tempfile.TemporaryDirectory(prefix='cbz-composition-review-') as directory:
        repo = Path(directory)
        copied = repo / 'frontiers' / packet.name
        shutil.copytree(packet, copied, ignore=shutil.ignore_patterns('.lake', '__pycache__'))
        (repo / 'tools').mkdir()
        shutil.copy2(ROOT / 'tools/lean_packet_admission.py', repo / 'tools/lean_packet_admission.py')
        manifest = json.loads((copied / 'MANIFEST.json').read_text())
        for pin in manifest['pins_on_main']:
            target = repo / pin['path']
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(ROOT / pin['path'], target)
        gate['source_check'](copied, repo)
        path = copied / 'CapFirstExit.lean'
        before = path.read_text()
        if before.count(anchor) != 1:
            raise RuntimeError('probe anchor must occur exactly once')
        after = before.replace(anchor, anchor + tail)
        path.write_text(after)
        for entry in manifest['files']:
            if entry['path'] == 'CapFirstExit.lean':
                data = path.read_bytes()
                entry.update(sha256=hashlib.sha256(data).hexdigest(), bytes=len(data))
        (copied / 'MANIFEST.json').write_text(json.dumps(manifest))
        gate['source_check'](copied, repo)
        observations.append(dict(tail=tail, clean_control_pass=True, injected_source_check_pass=True,
                                 continuation_unchanged=admission['continuation_binding'](before) ==
                                 admission['continuation_binding'](after)))

class SetupFailure(unittest.TestCase):
    def setUp(self):
        self.fail('fixture initialization failed')

    def test_never_runs(self):
        raise RuntimeError('test body must never run')

stream = io.StringIO()
unittest.TextTestRunner(stream=stream, verbosity=2).run(
    unittest.defaultTestLoader.loadTestsFromTestCase(SetupFailure))
result = subprocess.CompletedProcess([], 1, '', stream.getvalue())
print(json.dumps(dict(source_tail_probes=observations,
                     setup_failure_transcript=stream.getvalue(),
                     setup_failure_classification=runner['classify'](result, expected_count=1)), indent=2))
