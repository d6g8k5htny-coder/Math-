set -euo pipefail
python -B -S frontiers/determinant_moment_20261025/gate.py --execute 2>&1 | tee frontiers/determinant_moment_20261025/.lake/formal-evidence/authoritative-gate.log
