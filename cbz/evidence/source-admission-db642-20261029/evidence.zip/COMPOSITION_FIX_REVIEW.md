# Math composition fix re-review

**P1 — Declaration prefixes admit unbound same-line command tails: NOT ADDRESSED.**

Location: `tools/lean_packet_admission.py:121`–`:124`, specifically the positional `zip(text.splitlines(), code.splitlines())` in `_declaration_binding`. The new binding covers ordinary declaration lines, but raw text and lexical code need not have corresponding `splitlines()` positions. `code_only` retains LF inside comments and removes other comment characters, including U+2028; Python `str.splitlines()` recognizes U+2028 in the raw text. Consequently the selected raw line can be a different line inside a stripped comment rather than the actual declaration/header whose opaque remainder is being admitted.

The completed direct helper probe reported in the reviewer's prior message used trusted text `def d := 0\n` and the following changed text (escape notation denotes actual characters):

```python
'/- \u2028x\u2028def d := 0\n-/\ndef d := 0 newUnknownCommand cbz\n'
```

Its reported normal-mode result was an equal declaration binding, equal continuation binding, and successful census admission with the original reviewed metadata. The declaration hash in both cases was `d15cfcf3d5fdce19a03cf46d41feb1dba25810c8594a20ed9336ee710910effb`, with one bound line. This retains the completed direct-probe observation; it is not an independently repeated probe or a claim that the injected syntax elaborates in Lean. An optimized-mode reproduction and the proposed full Cap adapter investigation are **NOT_COMPLETED**.

The fix needs a line mapping that cannot diverge when comments or literals contain separators. The boundary remains in scope: it is introduced by the new header fingerprint selection and allows the opaque header tail to escape that binding. This does not require a general Lean parser. Existing normal same-line-tail regressions are useful but do not answer this mapping defect.

**P2 — Setup assertion failures can be counted as mutation kills: ADDRESSED provisionally, based on inspected code and retained logs.**

Locations: `tests/run_source_admission_mutations.py:64` (`run_unittest` lifecycle instrumentation), `tests/run_source_admission_mutations.py:126` (`phase_evidence`), and `tests/run_source_admission_mutations.py:155` (`classify`). The runner records body entry and failure phase in the actual unittest subprocess. Acceptance requires complete positive matching discovery, body entry for every test, and exclusively recorded body assertion failures for kills. Setup, teardown, cleanup and class/module errors cannot satisfy that predicate; unsupported lifecycle overrides fail closed. The original exit/transcript requirements remain.

The added real unittest lifecycle tests in `tests/test_source_admission_mutations.py:16` cover setup, teardown, cleanup, custom teardown, class setup, body error and empty discovery, together with positive body failure/success and timeout controls. The retained lifecycle logs report setup/teardown/cleanup rejection in both modes. This verdict is provisional only because platform interruption ended further investigation; no unresolved P2 defect was found in the inspected diff or verified evidence, and no additional test execution is claimed.

## New breakage in the fix diff

**Important — Header-binding line correspondence can diverge**, `tools/lean_packet_admission.py:122`. This is the remaining P1 defect above, not a separate duplicate finding. No additional Critical/Important breakage was identified in the inspected fix delta. The P2 implementation had no independently identified new breakage.

## Checks completed before interruption

Review range: `f1a17bf66869d11d4b1618dd148701b6f1b2e922` to `60f9912a2dacfc780bb9219482f694e89975a207`; head tree `97eac729c36bdd429e2cf29932c6120aa3f4d78c`.

- Read the requirements, original findings, appended implementation report and prebuilt fix package. The package was inspected in passes because tool output truncated; no redundant git diff or broad branch review was performed.
- Independently verified all 14 amended committed/current blob hashes against the exact-head evidence, plus the exact commit, parent and tree identities.
- Independently rehashed 19 validation logs. Their retained output supports helper 18, determinant 117, Cap 45 and runner 10 tests per mode; workflow discovery is `[18, 10, 117]` in each mode. These are inspected prior execution records, not reruns by this reviewer.
- Independently rehashed all 72 mutation/result/baseline logs. The retained complete matrix contains 30 body-assertion kills, six unmodified controls and 36 positive matching baselines, with both modes and no duplicate cases. Failure-phase records were independently checked against actual failure summaries.
- Rehashed the 16 completed lifecycle log files underlying the 18 lifecycle observations; the two timeout records have no completed subprocess/log result. Verified their reported classifications. No blanket suite or mutation-matrix rerun was performed.
- Independently compared all 95 protected files to original baseline `8151f592918a845bf19eb8eafaf8444540a32734`: byte-identical. Public targets remain determinant 66 and Cap 152; census and continuation metadata equal the reviewed fix base. Header bindings recompute from the unchanged current source.
- Independently AST-compared the six published determinant compiled/receipt functions with `74565f013575b7b05ecfc4034cd5d638ee355353`: identical. Its compiled helper is byte-identical, and compiled inventory remains null. All registry input digests match.
- Verification command `python -B -S composition-fix/review_verify.py` exited 0. The script and result are retained under `composition-fix/review_verify.py` and `composition-fix/review-evidence-verification.json`. This command verifies identities and retained logs; it does not run the test suites or Lean.

## Out-of-scope observations and limits

Actual native build, leanchecker replay, compiled inventory observation and qualification remain outside this source fix review and belong to the separately active unit. No kernel, scientific, closure, quarantine or qualification promotion is made. The inherited compiled safeguard remains unchanged and null/unqualified.

A platform cybersecurity-risk flag interrupted the turn after the reported direct probe. On the controller's instruction, no stopped probe was retried, no additional test or full-adapter investigation was executed, and no tool-control changes were made. This report retains only observations already completed. The full-adapter and optimized direct-probe investigations remain **NOT_COMPLETED**; they must not be represented as successful reproductions.

The checkout, index, HEAD and branch were not modified. Only review evidence/report files outside the worktree were written. No proof edits, test weakening/deletion, canonical root edits, remote writes or subagents occurred.

## Verdict

**Fix round: Findings remain open — P1 NOT ADDRESSED. P2 provisionally ADDRESSED based on inspected code/logs. Ready-to-publish source verdict: NO.**
