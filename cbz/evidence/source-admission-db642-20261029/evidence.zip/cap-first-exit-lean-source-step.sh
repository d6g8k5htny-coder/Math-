set -euo pipefail
for optimization in '' '-O'; do
  python -B $optimization -S - <<'PYCONTROLS'
import unittest
suite = unittest.defaultTestLoader.discover('tests', pattern='test_lean_packet_admission.py')
if suite.countTestCases() == 0:
    raise SystemExit('zero admission tests discovered')
if not unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful():
    raise SystemExit(1)
PYCONTROLS
done
P=frontiers/cap_first_exit_lean_20261002
python -B -S -m unittest discover -s "$P" -p 'test_*.py' -v
python -B -O -S -m unittest discover -s "$P" -p 'test_*.py' -v
python -B -S "$P/gate.py"
