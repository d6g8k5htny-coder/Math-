"""Record exact task-scoped local executions; no Lean runtime is invoked."""
from pathlib import Path
import subprocess, json, hashlib, datetime, time
ROOT=Path('/workspace/scratch/db6428847655/cbz/worktrees/math-cbz')
OUT=Path(__file__).resolve().parent
commands=[
 ('helper', ['-m','unittest','discover','-s','tests','-p','test_lean_packet_admission.py','-v']),
 ('determinant', ['-m','unittest','discover','-s','frontiers/determinant_moment_20261025/tests','-v']),
 ('cap', ['-m','unittest','discover','-s','frontiers/cap_first_exit_lean_20261002','-p','test_*.py','-v']),
 ('source-determinant', ['frontiers/determinant_moment_20261025/gate.py']),
 ('source-cap', ['frontiers/cap_first_exit_lean_20261002/gate.py']),
]
records=[]
for name,args in commands:
 for optimized in [False,True]:
  label=name+('-optimized' if optimized else '-normal');argv=['python','-B']+(['-O'] if optimized else [])+['-S']+args
  start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
  proc=subprocess.run(argv,cwd=ROOT,capture_output=True,text=True,timeout=600)
  log=OUT/(label+'.log');log.write_text(proc.stdout+proc.stderr)
  record=dict(label=label,argv=argv,cwd=str(ROOT),started=start,seconds=time.monotonic()-t,exit_code=proc.returncode,log=log.name,sha256=hashlib.sha256(log.read_bytes()).hexdigest())
  records.append(record);(OUT/'execution-summary.json').write_text(json.dumps(records,indent=2)+'\n')
  print(label,proc.returncode,flush=True)
