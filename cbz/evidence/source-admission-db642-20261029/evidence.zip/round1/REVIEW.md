# Math source-admission correction: scoped round-1 review

**Reviewed revision:** `c2bb435c627937ff03434d37ec9b2835c0d2c724`.
**Reviewed delta:** `e01cbef27e788782122f7fc3088fb4807170d52f..c2bb435c627937ff03434d37ec9b2835c0d2c724`.

**Specification verdict for the correction: compliant within the documented bounded source-admission scope. Task quality verdict: APPROVED for this frozen source revision.** Both P1 findings from the first review are addressed. No new actionable defect was found in the correction. This is not hosted/kernel qualification, a complete Lean parser certification, or approval of a future integration commit.

## Prior findings

### P1: indentation bypassed the command boundary — ADDRESSED

Relevant implementation: `tools/lean_packet_admission.py:85` (`continuation_binding`), `:96` (`_continuation_binding`), `:109` (`check_continuation`), and the final continuation check in `census`; adapter integration in `frontiers/determinant_moment_20261025/gate.py:183` and `frontiers/cap_first_exit_lean_20261002/gate.py:169`.

The former unconditional indentation admission is now conditional on an exact manifest-bound fingerprint of ordered nonempty indented lexical code lines and each line's preceding column-zero code anchor. The helper default refuses nonempty unbound continuations. Explicit metadata requires exactly a SHA-256 string and a nonnegative integer count; a boolean does not satisfy the count schema. A malformed or different fingerprint rejects.

Both adapters require precisely the expected module-key inventory and non-null per-module binding, and pass the manifest binding into `census`. They do not automatically approve a fingerprint calculated from the incoming source. This matters: a rebind of ordinary source-file hashes cannot authorize the previous appended, between-declaration or in-proof insertions. Their code lines change the continuation fingerprint. Moving a continuation across a different column-zero anchor also changes the fingerprint.

The helper and full-adapter regressions cover the previously accepted unknown command and `register_option` spellings, with actual source-digest rebinding and unchanged admission metadata. Tests include after-namespace, between-declaration and existing-proof positions. Separate mutants remove continuation checking or replace each adapter's manifest binding with input-derived autoapproval; the retained latest evidence shows these mutants killed.

This is a conservative source identity boundary for opaque continuations, not parsing of their complete Lean grammar. That is an acceptable implementation of the requested bounded repair, and is now explicit in both READMEs. Deliberately rebinding the continuation fingerprint is a change to the reviewed admission boundary and needs source review; it is not an independently demonstrated syntax qualification. The approval here relies on that stated boundary and does not generalize to arbitrary new fingerprints.

### P1: direct `sorryAx` escaped refusal — ADDRESSED

Relevant implementation: `tools/lean_packet_admission.py:15` and the global forbidden-token check at `:128`.

`sorryAx` is now explicitly forbidden, and token refusal precedes continuation comparison. Qualified references such as `_root_.sorryAx` expose the same token. The helper regression supplies a deliberately matching continuation binding and still requires a forbidden-token error; both adapter regressions do the same for an unused local placeholder term. This demonstrates that stale continuation metadata cannot mask a missing placeholder check.

The direct-placeholder removal mutant is also present and killed in both Python modes. The correction therefore addresses the original failure independently of the new continuation boundary.

## Fix-round quality and preservation

- The column-zero variable command check now uses a full match instead of accepting an arbitrary suffix after a binder prefix. `open ... in ...` wrappers are refused, and symbol-only input produces the intended controlled rejection. Focused regressions and dedicated removal mutants cover these changed boundaries.
- The fixed-helper path, ancestor symlink refusal, digest verification and execution of exactly the verified bytes are preserved. Additional metadata does not introduce a path redirection or unverified import.
- Both existing public target lists and both complete source-census lists are identical to predecessor `e01cbef`. The new continuation metadata binds 13 determinant modules and one Cap module without duplicating or editing the proof corpus.
- I independently compared all 95 protected proof/original/control/toolchain/Lake-pin paths against base `8151f592918a845bf19eb8eafaf8444540a32734`; all remain byte-identical. No proof body, statement, hypothesis or source visibility changed.
- The correction changes only the ten helper/test/adapter/manifest/README files identified in the handoff. Workflows, core formal gate and compiled execution/rejection-control implementation remain unchanged in this delta.
- Cap's existing mid-execution simultaneous source/manifest rewrite test now also rebinds the continuation metadata to keep its fixture self-consistent. Its original exact stale-manifest rejection assertion remains in place. This adaptation preserves the test's intended execution-time boundary rather than weakening it.
- Earlier failing runs are retained and clearly distinguished from the latest verified results. No test deletion, claimed mathematical promotion or fabricated hosted result was found in the correction.

## Evidence checked

Authoritative evidence directory: `round1/verified/`.

I inspected the fix diff, changed helper/adapter/test logic, latest mutation harness and the appended handoff. I verified every retained raw log digest against the latest summaries and checked the outcome markers:

- Ten execution records, all exit zero: helper 17, determinant 84 and Cap 43 tests in each of normal/optimized modes, plus both packet source gates in each mode.
- Twenty-eight mutant executions, each with a nonzero result, actual `FAIL:` assertion, nonzero test discovery and no setup `ERROR:`. This supports 14/14 scoped mutants killed per mode.
- Six unmutated same-harness controls, all with nonzero test discovery and `OK` results.
- All ten file SHA-256 entries in `commit.json` independently match both their frozen committed git blobs and the inspected worktree bytes.
- The 95 protected-file comparisons and unchanged target/census lists were independently verified, as described above.

The mutation harness deliberately rebinds the changed helper SHA when needed, so removal experiments measure the intended control rather than failing only at helper integrity. Same-harness controls make the rejection observations more credible. These are still scoped source/test results, not general auditor qualification.

No suite rerun was performed for this review. No new source mutation, additional agent, remote action or Lean execution was needed.

## Limits and integration boundary

Actual hosted Lean build, leanchecker replay, compiled target axiom audit and compiled rejection controls for the repaired revision remain unverified by this reviewer. Fresh actual hosted evidence is required before a new kernel claim. The source census and exact continuation fingerprints do not award G2 all-compiled-constant coverage, full G0/G4/G6, semantic alignment, vacuity, all Layer A or scientific acceptance.

This approval is frozen to `c2bb435c627937ff03434d37ec9b2835c0d2c724`. The separately merged Math528 change at `74565f0`, including its determinant gate/manifest changes, was not part of this review. A future composition must reconcile those overlapping files and be checked and tested at its own exact head; this review supplies no certification of that composition.
