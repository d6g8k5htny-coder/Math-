# Math packet source-admission review

Reviewed commit: `e01cbef27e788782122f7fc3088fb4807170d52f`, against `8151f592918a845bf19eb8eafaf8444540a32734`.

**Specification verdict: issues remain. Task quality verdict: NEEDS FIXES.** The repair closes the demonstrated ordinary declaration omissions and implements a sound fixed-helper byte verification boundary, but the new scanner still admits unsupported command syntax and a direct logical-placeholder reference. These conflict with the fail-closed source-admission requirements. Do not publish this revision as a completed admission repair.

## Findings

### P1 — Indentation bypasses the supported-command boundary

Location: `tools/lean_packet_admission.py:131` (unconditional continuation at lines 131–134; command allowlist begins at line 135).

Every nonempty indented line that avoids the finite keyword denylist is assumed to be an existing proof/header/structure continuation. There is no check that a declaration body is active or that this line belongs to it. In particular, a trailing indented command after all packet namespaces are closed never reaches the command allowlist.

Focused full-adapter probes appended each of these lines to a throwaway copy of each packet's existing source:

```lean
  newUnknownCommand cbz
```

```lean
  register_option cbzHidden : Bool := { defValue := false, descr := "review" }
```

After rebinding packet file hashes (and Cap byte counts), both source gates accepted both probes with the original census, target lists and helper digest untouched. `review-probes.json` records all four acceptances. The first probe establishes admission of unparsed syntax directly; the second exposes the same route for a metaprogramming command outside the claimed subset. These are source-admission observations, not a claim that either probe has been compiled in the pinned Lean environment.

The existing rejection test covers `newUnknownCommand x` only at column zero, so it misses this branch. The denylist catches the tested `alias` spelling, but adding individual denied names cannot establish that all remaining indented commands are continuations.

Requested correction: distinguish supported declaration/header/body continuations from top-level commands with a bounded fail-closed rule, or bind the admitted continuation language sufficiently narrowly to reject unsupported command insertion. Keep all existing proof bytes unchanged. Add direct helper and digest-rebound packet regressions for indented unknown and unsupported command forms, including after a closed namespace and inside a namespace between declarations. Retain the explicit compiled-census limitation.

### P1 — Direct `sorryAx` is admitted by both source gates

Location: `tools/lean_packet_admission.py:14` (forbidden set at lines 14–15, enforced at lines 88–90).

The logical-placeholder denylist contains `sorry` and `admit` but omits the directly accessible `sorryAx` constant. Exact token matching therefore accepts a direct placeholder reference. The existing Cap denylist also omits it, so that adapter supplies no additional protection.

The focused probe inserted the following first line into an existing `:= by` proof in a throwaway packet copy:

```lean
  have cbzUnused : False := sorryAx False true
```

After rebinding packet file hashes, **both full source gates accepted** it with unchanged census, targets and helper digest. This is not merely helper-only behavior. The existing compiled-axiom negative controls already identify `sorryAx` as forbidden, but their target audit is a later and distinct boundary; it cannot establish the source-level refusal promised here, particularly for unused code. No claim is made about whether a subsequent compiled target audit would detect this exact unused local term.

Requested correction: refuse direct logical-placeholder constant tokens, at least `sorryAx`, including qualified references and unused terms, and add both helper-level and digest-rebound packet regression coverage. Use actual rejection-reason checks to avoid passing only because a census or unrelated syntax check happened to fail.

## Checks that support the implementation

- The fixed helper path is constructed in each adapter rather than read from the manifest. Metadata keys and SHA format are checked. The file and all path ancestors are checked for symlinks. The code reads helper bytes, compares their SHA, and compiles/executes those same verified bytes; there is no second import read or pyc substitution. I found no defect in this trust boundary within the stated threat model.
- Exact ordered census comparison is invoked by both adapters before public target selection. The selection uses the verified census rather than the old source regex. Supported private declarations, definitions, abbrev, named instances and structures are recorded. Normal/indented/attributed/protected forms in the implemented controls cannot silently disappear through those tested spellings.
- The helper rejects unterminated strings/comments, unsupported quoting/interpolation and unbalanced named scopes; it preserves comment token gaps and handles nested comments. These controls do not make the remaining arbitrary continuation branch safe.
- No tracked Lean source, retained `.lean.txt` control/source, toolchain or Lake pin changed in the reviewed diff. I independently compared all 95 paths listed in `proof-preservation.json` with the base git objects; all match byte-for-byte.
- I independently compared both manifests against the base. Only `files` and `source_admission` changed at top level. Existing file identities changed only for README, gate and packet test files. The original target lists are identical (66 determinant, 152 Cap). The changed-file list contains no core formal gate file. No test deletion or weakening was found in the diff.
- Existing execution/build/leanchecker/target-axiom and rejection-control functions are preserved; source-census work does not replace their role.
- The new determinant workflow has narrow packet/helper/test/workflow triggers, pinned actions, explicit nonzero test discovery in both modes, existing `gate.py --execute`, and an always-run evidence upload. Cap's existing workflow gains helper/control triggers and nonzero shared-test checks. The workflow design retains real gate failure status and logs; no source-only result is relabeled a hosted result.
- README and handoff language correctly distinguish the source census from G2, generated/private/auxiliary compiled constants, complete dependency closure, scientific acceptance and hosted execution. Those limitations are appropriate but do not excuse the two failures inside the expressly promised source-admission boundary.

## Evidence assessed without suite reruns

I read the requirements before the implementation and inspected the supplied diff, relevant adapter/scanner source, tests and scoped mutation harness. I verified retained raw log SHA-256 values against all 16 `execution-summary.json` entries, all 16 `mutation-summary.json` entries and both `workflow-checks.json` entries. The suite logs contain the reported counts in each Python mode: helper 13, determinant 81, Cap 40, core 244, SIDE24 30, with `OK` results. The six source-gate observations are source-only passes.

The 16 mutation logs contain actual `FAIL:` assertions, no `ERROR:` setup results and no zero-test discovery; this supports the reported 8/8 scoped mutants killed per mode. The mutation harness isolates checker removals in temporary copies. This is meaningful but does not cover the missing token or the permissive continuation branch identified above.

I did not rerun these suites. New execution was limited to the six focused source-gate probes needed to resolve the concrete concerns. They used temporary packet copies; committed proofs and files were not modified. Probe outcomes are retained in `review-probes.json` alongside this review.

## Cannot verify / remaining qualifications

- No actual hosted Lean build, leanchecker replay, target axiom report or compiled negative control for this changed commit was available or executed by this reviewer. Workflow configuration and local source-step results establish feasibility only, not a kernel pass. Fresh hosted execution remains required after fixes and byte rebinding.
- The exact pinned compiler interpretation of the added probe snippets was not tested. The findings are confirmed failures of source admission against its explicit supported-syntax and placeholder-refusal contract; they do not assert a successful end-to-end kernel exploit.
- Complete compiled-constant census, imported/generated constant closure, full G0/G2/G4/G6 qualification, semantic alignment, vacuity, all Layer A and scientific acceptance are outside the evidence reviewed.
- No remote actions, publication, canonical registration or additional agents were used by this reviewer.

Re-review should check the two corrections, their exact helper/manifest rebinding and focused regression evidence before approving the admission repair. All proof-preservation constraints remain mandatory.
