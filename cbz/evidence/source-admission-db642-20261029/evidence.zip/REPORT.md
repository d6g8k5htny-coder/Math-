# Math packet source admission repair — Task 1 handoff

Contribution: CBZ-VERIFIER-AUDIT-DB642 / main#684. Base Math commit:
`8151f592918a845bf19eb8eafaf8444540a32734`. Branch:
`codex/cbz-auditor-closure-20261029`. Scientific effect: NONE.

Task 1 is implemented and locally source/test-qualified. Commit: `e01cbef27e788782122f7fc3088fb4807170d52f`. Remote publication,
independent source review, actual hosted Lean execution and canonical registration
belong to the parent. No remote writes, pushes, comments, subagents, or compiler/
host-control bypasses were performed by this worker.

## Implementation

- Added `tools/lean_packet_admission.py`, a standard-library bounded
  source scanner/census. Records have exact ordered module, namespace, source
  name, declaration kind and privacy fields.
- Supported current forms include private/public theorem/lemma, definitions,
  abbreviations, named instances, structures, named namespaces/sections,
  variables, existing open/import commands, exact `set_option autoImplicit false`
  and the current Cap omit wrapper. Unsupported declaration-bearing and
  metaprogramming spellings are refused. Indented/attributed/protected forms do
  not silently disappear; they are rejected. Existing private declarations are
  inventoried without altering source visibility.
- Nested block/line comments, plain/raw strings, escaped characters, Lean image
  notation and primed identifiers are handled without treating literal contents
  as declarations. Unterminated input, quoted syntax, interpolation and supported
  subset violations reject. Known logical-placeholder/custom-axiom/native/trust
  escape tokens reject even in unused definitions or qualified references.
- Both packet adapters validate manifest metadata shape, fixed helper path,
  SHA-256 format, and every helper-path ancestor for symlinks. They read bytes,
  verify SHA-256, then execute exactly those verified bytes, avoiding importlib
  rereads or pyc-cache substitution. The manifest cannot redirect the helper.
- Exact census equality precedes existing target checks. Execution target
  selection now uses verified records, preventing comment-fabricated targets.
  Existing public target ABI is unchanged: determinant 66, Cap 152.
- Determinant census has 106 records: 71 theorem, 14 lemma, 19 def, one abbrev,
  one named instance; 19 private and 87 public. Cap has 152 records: 138 theorem,
  13 def, one structure; all public. Structure-generated constants are NOT counted
  as source records or claimed covered by this census.
- Only README, gate and test hashes changed in each manifest's existing `files`
  field. Separate `source_admission` metadata binds helper SHA and exact census.
  No existing manifest target, axiom, dependency, status or source proof hash was
  changed. Cap's original one-space manifest indentation is preserved.
- Cap's existing workflow also triggers on shared helper/control changes. A new
  narrow determinant workflow uses the same exact checkout/setup-python/
  lean-action/upload-artifact pins and Mathlib cache pattern. Both source-test
  routes explicitly require nonzero shared-test discovery; determinant also
  guards its packet suite. Build/replay/axiom/negative-control execution remains
  in the existing packet gates, unchanged by this task.

## RED evidence

`red-determinant.log`: 56 tests, six failing subcases in the new digest-rebound
admission regression. Five additions (private, indented, attributed, unused
axiom, unused sorry definition) were accepted by the original gate. The native
addition was rejected only by the old target list, not the required forbidden
source-token check; the exact-reason test failed as intended.

`red-cap.log`: 39 tests, three failing omission subcases (private, indented,
attributed declarations accepted); existing forbidden-token controls already
rejected axiom/sorry/native cases. All source hashes, including changed bound
test hashes, were rebound in each fixture before checking admission. Final RED
logs contain no setup errors from stale test hashes.

Additional retained developmental RED logs: `red-image-notation.log` (missing
recognition of Lean set-image `''`), `red-alias.log` (indented alias omission),
`red-comment-target.log` (old determinant regex fabricated a target inside a
comment), `red-ancestor-symlink.log` (symlink ancestor escaped the initial narrow
path checks). Their subsequent positive controls are included in final GREEN.
No RED output was discarded or rewritten as a success receipt.

## Final local GREEN and exact executions

`execution-summary.json` records exact argv, cwd, UTC start times, exit status,
elapsed seconds and SHA-256 of each raw output log. All 16 final commands exited
zero. Counts in EACH normal and optimized Python mode (`-B -S`, `-B -O -S`):

| Suite | Tests per mode |
|---|---:|
| Shared helper / both adapter integrity controls | 13 |
| Determinant packet, all existing test files | 81 |
| Cap packet, all existing test files | 40 |
| Core formal regression (unchanged) | 244 |
| SIDE24 existing exact arithmetic regression | 30 |

The determinant, Cap and core source gates also each exited zero in both modes.
No skipped test or Lean execution is represented as a passing kernel check.
This is task-scoped regression, not a repository-wide full test result.

`workflow-checks.json` records YAML parsing, required path-trigger/pinned-action
checks, `bash -n`, and actual local execution of each workflow's source-test shell
step. Both shell steps exited zero and discovered nonzero suites. Raw generated
shell scripts and output are retained. Lean install/build steps were NOT executed
by this local workflow simulation; it is not a GitHub-hosted result.

## Auditor self-mutations

`run_mutations.py` makes fresh throwaway copies and executes eight isolated
checker-removal mutants in both Python modes. Each kill requires a nonzero test
result with an actual `FAIL:` assertion and no `ERROR:` setup failure or zero-test
result. `mutation-summary.json` and all 16 raw logs record the observations.

| Removed check | Mutants | Killed in each mode |
|---|---:|---:|
| Helper forbidden-token refusal | 1 | 1 |
| Helper exact census equality | 1 | 1 |
| Packet census invocation | 2 | 2 |
| Packet pre-execution helper SHA verification | 2 | 2 |
| Packet helper/ancestor symlink refusal | 2 | 2 |
| Total | 8 | 8 |

Observed result: **8/8 scoped mutants killed per mode, 16/16 executions**. This
bounded result does NOT qualify full G0, repository-wide G6 or all auditor paths.

## Preservation and self-review

`proof-preservation.json` compares 95 tracked packet Lean sources, retained
`.lean.txt` originals/controls/evidence sources, toolchains and Lake pins against
the exact base commit. All are byte-identical. The manifest target lists are
exactly equal and the only changed manifest top-level keys are `files` and new
`source_admission`. Existing execution functions, rejection controls and core
formal gate code are unchanged. `git diff --check` passed.

The scanner is intentionally bounded. It preserves actual frontier grammar
rather than transplanting the core theorem-only grammar, which rejects legitimate
frontier private declarations, abbrev/instance/structure forms and scopes. Shared
helper tests are independent of packet import paths; each adapter retains its own
pre-use integrity boundary. No proof body was altered to accommodate scanning.

## Precise residual / publication requirements

- Local Lean is unavailable per the inherited host observation (failed to locate
  application / process-path denial). This worker did not retry via alternate
  compiler paths, weaken host controls, alter compiler bytes, or manufacture logs.
- Actual hosted execution of the changed checker/census commit is **UNRUN by this
  worker**. Parent must observe real Cap and determinant workflow build,
  leanchecker, target axiom and negative-control output and preserve failures.
  Configuring workflows does not establish that those steps passed.
- This is a source declaration admission correction, NOT a complete Lean parser,
  a full lexical auditor qualification, or a G2 all-compiled-constant axiom audit.
  Imported/extensible commands, generated structure/private/auxiliary constants
  and their complete compiled dependency closure still require an independently
  qualified compiled-environment adapter and actual compiled mutations.
- G0/G2/G4, full G5/G6, semantic alignment, vacuity, all Layer A, parent theorem
  closure and scientific promotion are not awarded by these checks. Original
  MATH-ADMISSION findings' broader compiled-audit boundary remains open.
- Independent review/publication/canonical registration is pending the parent;
  no review identity or hosted receipt is invented here.

Standing owner links retained for handoff:
https://github.com/d6g8k5htny-coder/main/blob/b665307520948308a53d190d7341bf301df3b3a2/governance/OWNER_MANDATE_20261015.md
https://github.com/d6g8k5htny-coder/main/blob/b665307520948308a53d190d7341bf301df3b3a2/governance/OP-AUTONOMY-20260923-v2.1.md

# Review correction round 1 (predecessor e01cbef)

The independent source review in `REVIEW.md` found two P1 gaps in the initial
revision: arbitrary whitespace was still enough to admit an unparsed line, and
`sorryAx` itself was absent from the source placeholder set. The six accepted
full-gate probes in `review-probes.json` are preserved. Initial suite/mutation
success did not cover these two cases; the predecessor is not presented as the
completed admission repair.

## Correction and boundary

The blanket continuation assumption is replaced by an explicit reviewed
continuation boundary, **not** an expanding example-name denylist. Each module's
manifest now has a compact `source_admission.continuations` record with an exact
count and SHA-256 over ordered nonempty indented code lines and their preceding
column-zero code anchors, after lexical processing. Reanchoring an existing
continuation across a command boundary changes the binding. The manifests do not
duplicate the proof corpus. Determinant binds 13 modules / 1,250 code lines; Cap
binds one module / 4,401 code lines.

Both adapters require the exact module-key inventory and reject absent/null,
malformed, stale or changed bindings. The helper's standalone default refuses
unbound indentation. A source-file hash rebind never generates or updates this
separate boundary. Nonindented code still goes through the command subset:
variable commands must fully match their supported binder groups, and `open ...
in ...` command wrappers are refused. Symbol-only unsupported command input gets
a controlled ValueError rather than an indexing error. Parsed declaration,
namespace, forbidden-token and metaprogramming refusals still apply before any
continuation is admitted.

`sorryAx` is now refused as a token before continuation checking, including
`_root_.sorryAx`, `Lean.sorryAx`, and unused local terms. Tests also explicitly
rebind a malicious placeholder input's continuation fingerprint and still require
the exact forbidden-token rejection, independently of stale-boundary detection.

This is an intentionally conservative admitted-source boundary: current opaque
continuations are bound rather than purportedly parsed as arbitrary Lean terms.
An intentional continuation change, or simultaneous manifest change, requires
source review and actual hosted gates. Automatically regenerating that binding
would not establish qualification. The helper remains neither a complete Lean
parser nor an independent mathematical proof, and the G2 compiled all-constant
residual remains open.

## New RED and retained intermediate failure

- `round1/red-helper.log`: two test methods, nine failing subcases, consisting of
  six accepted indented unknown/register_option forms and three accepted direct
  placeholder references.
- `round1/red-determinant.log`, `round1/red-cap.log`: one focused test method per
  adapter, twelve accepted subcases EACH. These cover unknown command,
  register_option, sorryAx and qualified sorryAx after a closed namespace,
  between declarations and in an existing proof. Each fixture rebinds all ordinary
  packet file hashes/Cap byte counts while retaining census/continuation metadata.
- `round1/red-command-tail.log`: three failures exposed permissive variable
  prefixes and open-command wrappers. Their dedicated guards now have removal
  mutants.
- `round1/red-punctuation-command.log`: controlled-error fixtures exposed the
  empty-token indexing issue during refinement; that input now raises ValueError.
- The first covering Cap suite in `round1/cap-normal.log` and
  `round1/cap-optimized.log` had one real failure each:
  `test_source_and_manifest_rewritten_together_during_execution`. Its self-
  consistent source+manifest rewrite fixture did not yet rebind the new
  continuation boundary, so the new refusal preempted its intended stale-manifest
  execution check. The fixture now rebinds the continuation too, and its original
  exact `MANIFEST.json differs from the manifest bound before execution`
  assertion is retained. No rejection test was deleted or weakened.

## Verification artifacts

The final correction evidence is under `round1/verified/`; intermediate attempts
are retained in `round1/` and `round1/final/` and are not substituted for final
results. `execution-summary.json` records fresh helper/packet normal and optimized
runs and both source gates. `mutation-summary.json` records isolated checker
mutations plus unmutated controls from the exact same throwaway-copy harness.
Final result and commit binding are appended after those executions finish.

Core and SIDE24 code paths are unchanged and do not import this shared helper;
per parent scope they were not rerun in round 1. The initial 244 / 30 per-mode
observations remain historical evidence rather than new round-1 executions.
No Lean compiler, GitHub execution, remote write, subagent, or host-control
workaround was used. Actual hosted build/replay/axiom/negative-control evidence
is still pending the parent after this corrected source revision.

## Round-1 final result

Fresh final verification in `round1/verified/` completed with **all ten commands
exit 0**: helper 17, determinant 84 and Cap 43 tests EACH normal/optimized, plus
both source gates in both modes. No suite skip or setup error is counted as a
pass. Every final output digest was rechecked against its summary record.

Final auditor experiments: **14/14 scoped mutants killed per mode (28/28 mutant
executions)**. These retain the original eight removals and add six: shared
continuation-admission removal, direct sorryAx-token removal, each adapter's
continuation autoapproval in place of its manifest binding, variable-tail
boundary removal, and open-wrapper refusal removal. For the placeholder mutant,
tests supply matching continuation metadata, so a stale continuation cannot mask
the absent token refusal. Each kill requires actual assertion failure, nonzero
exit, nonzero discovery and no setup ERROR. **Six of six unmutated same-harness
controls pass** (shared helper and both adapters in each mode). All copies are
isolated, and a changed helper's SHA is deliberately rebound in the mutant
fixture to measure the intended checker rather than its independent integrity
check. These scoped numbers do not award G0, G2, G4 or full G6.

`round1/verified/proof-preservation.json` again records all 95 proof/original/
control/pin paths byte-identical to 8151f59. Both target lists and both exact
source-census lists are identical to reviewed predecessor e01cbef. Only the ten
owned helper/test/adapter/manifest/README files changed in this correction;
workflow code, compiled controls, core code and scientific metadata did not.
`git diff --check` passes. Scoped independent re-review and actual hosted Lean
execution remain pending the parent; neither is inferred from these results.

Round-1 correction commit: `c2bb435c627937ff03434d37ec9b2835c0d2c724`. `round1/verified/commit.json` binds all ten committed files to their tested SHA-256 values. Predecessor e01cbef is retained; no amend or remote action occurred.
