# Math composition review — changes required

Reviewed HEAD: `f1a17bf66869d11d4b1618dd148701b6f1b2e922`.
Reviewed tree: `327fd5a63b2540cdf7b2289456e1670a241ab1e8`.
Whole-branch comparison: published `74565f013575b7b05ecfc4034cd5d638ee355353` to HEAD, including the source repair inherited from `c2bb435c627937ff03434d37ec9b2835c0d2c724`.

**Ready-to-publish source verdict: NO — address P1 and P2 below and review the resulting exact revision.** The published compiled safeguard is preserved. This verdict concerns source/tooling acceptance, not mathematical validity or a hosted kernel result. Hosted actual Lean execution remains pending and is not certified by this review.

## Findings

### P1 — Declaration prefixes admit unbound same-line command tails

Location: `tools/lean_packet_admission.py:152`–`:163`, particularly `DECL.match(line)` and the unconditional `continue` after recording the declaration.

The declaration branch checks only the prefix and recognized declaration-keyword count. It neither validates the remainder of the column-zero line nor necessarily binds it in the continuation fingerprint. The fingerprint includes a column-zero anchor only when a later indented line uses that anchor. An existing complete one-line theorem followed by another column-zero command therefore has an unbound tail.

Concrete full-adapter reproduction: append the following text to the existing `toy_frontier` theorem at `frontiers/cap_first_exit_lean_20261002/CapFirstExit.lean:3343`:

```lean
 register_option cbzHidden : Bool := { defValue := false, descr := "review" }
```

In a disposable packet/repository copy, the original `source_check()` passes. After changing only that line and rebinding the ordinary `CapFirstExit.lean` file SHA/byte count, `source_check()` still passes. The source census, helper identity and continuation metadata are unchanged; the computed continuation fingerprint is also unchanged. A same-line `newUnknownCommand cbz` tail likewise passes. Both observations reproduce in normal and optimized Python modes.

This is the same unsupported-command admission boundary the repair is intended to close, reached through a declaration prefix rather than a separate indented line. The global forbidden-token set happens not to include `register_option`; merely adding that one word would leave arbitrary unknown tails admitted. The installed Lean source declares `register_option` as a command macro expanding to `initialize` (`Lean/Data/Options.lean:241`), making this a concrete declaration-bearing form rather than an arbitrary proof expression. Its use at a separate unbound line is already rejected by the existing tests.

Bind or soundly delimit the opaque remainder of declaration lines as well as indented continuations. Add helper and full-adapter regressions with unchanged reviewed admission metadata and rebound ordinary source hashes; preserve all existing proof bytes and target records. A narrow separately reviewed lexical binding is sufficient; a general Lean parser is not required.

A dependency-free direct Lean syntax probe was attempted once using the existing local 4.34.1 executable, but the executable failed before processing input with `error: failed to locate application`. No runtime/host control was changed or bypassed. Consequently this review demonstrates the source-admission escape, not successful elaboration of the injected program or a compiled/kernel bypass.

### P2 — Setup assertion failures can be counted as mutation kills

Location: `tests/run_source_admission_mutations.py:59`–`:75`, especially the `killed` predicate at `:72`.

The classifier accepts any nonzero unittest transcript with a positive matching `Ran` count, `FAIL: test_...`, `AssertionError:` and the matching failures-only summary. Python unittest produces exactly that transcript when a test's `setUp()` calls `self.fail()`: the test body never executes, but it is counted as one test and one failure. A real one-test unittest run with `setUp(): self.fail('fixture initialization failed')` is classified as `killed=True` with `expected_count=1` in both Python modes.

This violates the brief's explicit rejection of setup failures. A previously green selected baseline does not resolve it: a mutation can break a fixture before the intended assertion runs. Record enough execution phase information to distinguish test-body assertion failures from setup/teardown failures, and add a regression using a real unittest setup failure rather than only invented `ERROR:` text. Preserve the positive baseline and matching discovery requirements.

The existing reported 28 mutation logs do not contain setup/teardown failure frames; this finding does not retract those observed kills or allege fabricated results. It concerns future acceptance by the inheritable runner.

## Composition and evidence checks

- Independently compared all 95 protected proof/original/control/toolchain/Lake-pin paths against `8151f592918a845bf19eb8eafaf8444540a32734`: byte-identical. All 19 changed paths in the whole-branch diff match their inspected HEAD blobs.
- Public target lists remain exactly determinant 66 and Cap 152; both full source-admission metadata records equal c2bb435. The determinant's 19 private source declarations remain private. Fixed helper paths, ancestor-symlink rejection, digest checks, execution of verified helper bytes, exact census equality and manifest-provided continuation bindings are present.
- Independently AST-compared the six published compiled/receipt functions (`compiled_implementation`, `compiled_contract`, `audit_compiled`, `invalidate_active_receipt`, `execute`, `main`) with 74565f0: identical. The compiled helper is byte-identical to the published helper. The null compiled inventory remains unqualified and both CLI routes retain fail-closed behavior.
- Inspected the determinant workflow's exact Python and shell integration. Its source step calls `source_check()` and labels the result source-only. Observation verifies source/helper identity, executes the verified helper bytes, checks release/dependencies, makes a fresh ordinary build, runs leanchecker, executes the unchanged helper's inventory program and preserves raw output. Its status explicitly says UNQUALIFIED and acceptance false. It does not populate a compiled manifest or create a receipt. The subsequent full gate preserves failure via pipefail; artifact upload runs on failure. No kernel PASS is manufactured.
- Inspected the published fixture changes and compiled mutation runner copy-layout changes: they supply the new fixed repository-level helper dependency. Original assertions and compiled safeguards remain. The source mutation runner retains all fourteen actual mutation definitions, both modes, exact-once anchor checks, positive selected baselines, fresh output checks and aggregate failure. Its remaining setup-classification gap is P2.
- Independently rehashed all 19 final execution-record logs and all 68 final mutation/control/baseline logs. Digests and recorded expected exits match. Existing evidence supports helper 17, determinant 115, Cap 43 and runner 6 tests per mode, workflow discovery `[17, 6, 115]` per mode, 28 observed assertion kills, six full-suite controls and 34 positive selected/control baselines. All component registry input digests match current files.
- No broad suite or mutation-matrix rerun was performed solely for review. New work was confined to the concrete unresolved doubts above. `composition/review-focused-probes.py` and its normal/optimized JSON outputs preserve the reproductions. `composition/review-evidence-verification.json` preserves the additional evidence checks. No worktree source, index, HEAD, checkout, remote or canonical governance surface was modified; no subagent was used.

## Out-of-scope considerations

- Hosted package build, leanchecker replay, inventory observation and authoritative gate execution: still pending; local source evidence and syntax inspection cannot certify them. The failed local launcher probe is not mathematical impossibility or quarantine evidence.
- Private/auxiliary compiled-name representation and non-target theorem admission: a separately identified qualification gap in the unchanged compiled adapter. This task expressly preserves those rules, so changing them or guessing a census is outside this review's repair recommendation.
- Semantic alignment, vacuity, Layer A, federation G0/G2/G4/full-G6, scientific acceptance and CLOSED/quarantine dispositions: not established by source checks or the scoped mutation experiment. No such promotion is made here.
- Core and SIDE24 implementation, external workflow action internals and canonical governance/status records: no change in this branch requiring a new independent audit was identified. Existing published governance/quarantine records are inherited, not newly awarded by this review.
- General Lean parsing and all possible future command syntax: not claimed. P1 is in scope because it accepts arbitrary unreviewed command text with unchanged admission metadata in the current supported packet; correcting that boundary need not broaden into a parser project.
