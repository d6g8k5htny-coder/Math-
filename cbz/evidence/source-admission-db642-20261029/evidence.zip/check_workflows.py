from pathlib import Path
import yaml, subprocess, json, hashlib
ROOT=Path('/workspace/scratch/db6428847655/cbz/worktrees/math-cbz')
OUT=Path(__file__).resolve().parent
records=[]
for name in ['cap-first-exit-lean','determinant-moment-lean']:
 p=ROOT/'.github/workflows'/(name+'.yml');m=yaml.safe_load(p.read_text())
 for event in ['pull_request','push']:
  paths=m['on'][event]['paths']
  assert 'tools/lean_packet_admission.py' in paths
  assert 'tests/test_lean_packet_admission.py' in paths
 steps=m['jobs']['kernel-evidence']['steps']
 install=next(s for s in steps if s.get('uses','').startswith('leanprover/lean-action@'))
 assert install['uses']=='leanprover/lean-action@24581d74d674803a25a81b10b059c5c0cdd344c6'
 assert install['with']['use-mathlib-cache']=='true' and install['with']['build']=='false'
 script=next(s['run'] for s in steps if 'source' in s.get('name','').lower())
 target=OUT/(name+'-source-step.sh');target.write_text(script)
 syntax=subprocess.run(['bash','-n',str(target)],capture_output=True,text=True)
 assert syntax.returncode==0,syntax.stderr
 proc=subprocess.run(['bash',str(target)],cwd=ROOT,capture_output=True,text=True,timeout=180)
 log=OUT/(name+'-source-step.log');log.write_text(proc.stdout+proc.stderr)
 records.append(dict(workflow=p.relative_to(ROOT).as_posix(),source_step_argv=['bash',str(target)],yaml_parsed=True,bash_syntax_exit=syntax.returncode,source_step_exit=proc.returncode,log=log.name,sha256=hashlib.sha256(log.read_bytes()).hexdigest(),lean_execution='NOT_RUN'))
 (OUT/'workflow-checks.json').write_text(json.dumps(records,indent=2)+'\n')
 print(name,proc.returncode,flush=True)
