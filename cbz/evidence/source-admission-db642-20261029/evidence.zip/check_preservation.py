from pathlib import Path
import subprocess,json,hashlib
ROOT=Path('/workspace/scratch/db6428847655/cbz/worktrees/math-cbz')
OUT=Path(__file__).resolve().parent
base='8151f592918a845bf19eb8eafaf8444540a32734'
records=[];meta=[]
for packet,name in [('determinant_moment_20261025','manifest.json'),('cap_first_exit_lean_20261002','MANIFEST.json')]:
 directory=ROOT/'frontiers'/packet
 for path in sorted(directory.rglob('*')):
  if not path.is_file() or '.lake' in path.parts:continue
  if path.suffix!='.lean' and not path.name.endswith('.lean.txt') and path.name not in ['lean-toolchain','lakefile.toml','lake-manifest.json']:continue
  rel=path.relative_to(ROOT).as_posix();old=subprocess.check_output(['git','show',base+':'+rel],cwd=ROOT);data=path.read_bytes()
  records.append(dict(path=rel,base_sha256=hashlib.sha256(old).hexdigest(),current_sha256=hashlib.sha256(data).hexdigest(),byte_equal=old==data))
 old=json.loads(subprocess.check_output(['git','show',base+':'+str((directory/name).relative_to(ROOT))],cwd=ROOT));new=json.loads((directory/name).read_text())
 changed_keys=sorted(k for k in set(old)|set(new) if old.get(k)!=new.get(k))
 if changed_keys!=['files','source_admission']:raise RuntimeError('unexpected manifest key change '+str(changed_keys))
 meta.append(dict(packet=packet,targets_equal=old['targets']==new['targets'],target_count=len(new['targets']),changed_manifest_keys=changed_keys,source_census_count=len(new['source_admission']['census'])))
assert all(r['byte_equal'] for r in records)
(OUT/'proof-preservation.json').write_text(json.dumps(dict(base=base,files=records,manifests=meta),indent=2)+'\n')
print(len(records),'proof/original/pin files byte-equal; target ABI unchanged')
