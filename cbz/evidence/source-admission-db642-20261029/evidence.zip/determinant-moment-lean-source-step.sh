set -euo pipefail
for optimization in '' '-O'; do
  python -B $optimization -S - <<'PYCONTROLS'
import unittest
runner = unittest.TextTestRunner(verbosity=2)
for directory, pattern in [('tests', 'test_lean_packet_admission.py'),
                           ('frontiers/determinant_moment_20261025/tests', 'test_*.py')]:
    suite = unittest.TestLoader().discover(directory, pattern=pattern)
    if suite.countTestCases() == 0:
        raise SystemExit('zero tests discovered: ' + directory)
    if not runner.run(suite).wasSuccessful():
        raise SystemExit(1)
PYCONTROLS
done
python -B -S frontiers/determinant_moment_20261025/gate.py
