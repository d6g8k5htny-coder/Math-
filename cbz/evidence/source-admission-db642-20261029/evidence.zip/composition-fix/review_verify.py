from pathlib import Path
import ast, hashlib, json, os, re, subprocess
from datetime import datetime, timezone
E=Path('/workspace/scratch/db6428847655/cbz/implementation/math-admission/composition-fix')
R=Path('/workspace/scratch/db6428847655/cbz/worktrees/math-composition')
BASE='f1a17bf66869d11d4b1618dd148701b6f1b2e922'
HEAD='60f9912a2dacfc780bb9219482f694e89975a207'
PUB='74565f013575b7b05ecfc4034cd5d638ee355353'
def require(ok,msg):
 if not ok: raise ValueError(msg)
def git(*a):
 return subprocess.check_output(['git','--no-optional-locks','-C',str(R),*a],env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
def blob(rev,path): return git('show',rev+':'+path)
def sha(b): return hashlib.sha256(b).hexdigest()
def read(n): return json.loads((E/n).read_text())
def logcheck(record, folder):
 b=(folder/record['log']).read_bytes(); require(sha(b)==record['sha256'],record['log']+' digest'); return b.decode()
def phases(text,count):
 found=re.findall(r'^SOURCE_MUTATION_PHASES\|(.+)$',text,re.M); require(len(found)==1,'phase marker count')
 x=json.loads(found[0]); require(set(x)=={'tests','events'},'phase schema')
 require(len(x['tests'])==count and len({t['id'] for t in x['tests']})==count,'phase discovery')
 require(all(t['body_entered'] is True for t in x['tests']),'body entry')
 return x['events']
commit=read('commit.json')
require(git('rev-parse','HEAD').decode().strip()==HEAD,'head')
require(git('rev-parse','HEAD^{tree}').decode().strip()==commit['tree'],'tree')
require(git('rev-parse','HEAD^').decode().strip()==BASE,'parent')
for p,digest in commit['source_sha256'].items():
 require(sha((R/p).read_bytes())==digest and sha(blob(HEAD,p))==digest,'source '+p)
execs=read('execution-summary.json'); require(len(execs)==19,'19 executions')
counts={}
for record in execs:
 text=logcheck(record,E); require(record['exit_code']==record['expected'],'execution exit')
 matches=[int(x) for x in re.findall(r'^Ran (\d+) tests? in ',text,re.M)]
 if record['label'].split('-')[0] in {'runner','helper','determinant','cap'}:
  expected={'runner':10,'helper':18,'determinant':117,'cap':45}[record['label'].split('-')[0]]
  require(matches==[expected] and re.search(r'^OK$',text,re.M) and 'FAILED' not in text,'suite '+record['label'])
 if matches: counts[record['label']]=matches
 if record['label'].startswith('cli-unqualified'):
  require(record['exit_code']==1 and 'CBZ_COMPILED_INVENTORY_UNQUALIFIED' in text,'CLI refusal')
matrix=read('mutations/mutation-summary.json'); require(len(matrix)==36,'matrix size')
keys={(x['name'],x['optimized']) for x in matrix}; require(len(keys)==36,'duplicate matrix')
base_names={x['name'] for x in matrix if not x['control']}; require(len(base_names)==15,'mutants')
require(all((n,m) in keys for n in {x['name'] for x in matrix} for m in [False,True]),'both modes')
kills=controls=0
for record in matrix:
 for entry in [record['baseline'],record]:
  text=logcheck(entry,E/'mutations'); matches=re.findall(r'^Ran (\d+) tests? in ',text,re.M)
  require(matches==[str(entry['collected'])] and entry['collected']>0,'matrix discovery')
  events=phases(text,entry['collected'])
  require(not re.search(r'^ERROR:',text,re.M),'matrix errors')
  if entry is record and not record['control']:
   fs=re.findall(r'^FAIL: test_',text,re.M)
   require(entry['exit_code']!=0 and len(fs)>0 and 'AssertionError:' in text,'assertion kill')
   require(re.search(r'^FAILED \(failures='+str(len(fs))+r'\)$',text,re.M),'failure summary')
   require(len(events)==len(fs) and all(e['phase']=='body' and e['kind']=='failure' for e in events),'only body failures')
   kills+=1
  else:
   require(entry['exit_code']==0 and not events and re.search(r'^OK$',text,re.M),'positive baseline/control')
 require(record['collected']==record['baseline']['collected'],'matching discovery')
 if record['control']: controls+=1
probes=read('lifecycle-probes.json')
for probe in probes:
 if 'log' in probe: logcheck(probe,E)
 if probe['name'] in {'setup','teardown','cleanup','custom_teardown','body_error','empty','timeout'}:
  require(not probe['killed'] and not probe['control_pass'],'lifecycle rejection')
protected=read('proof-preservation.json')
for item in protected['files']:
 b=blob(protected['base'],item['path']); require(b==(R/item['path']).read_bytes(),'protected '+item['path'])
require(len(protected['files'])==95,'protected count')
namespace={}; exec(compile((R/'tools/lean_packet_admission.py').read_bytes(),'<verified helper>','exec'),namespace)
manifest_summary={}
for p,name in [('frontiers/determinant_moment_20261025/manifest.json','determinant'),('frontiers/cap_first_exit_lean_20261002/MANIFEST.json','cap')]:
 current=json.loads((R/p).read_text()); old=json.loads(blob(BASE,p)); a=current['source_admission']
 require(current['targets']==old['targets'],'targets')
 require(a['census']==old['source_admission']['census'] and a['continuations']==old['source_admission']['continuations'],'reviewed metadata')
 require(a['helper_sha256']==sha((R/'tools/lean_packet_admission.py').read_bytes()),'helper hash')
 for module,binding in a['declarations'].items():
  path=R/Path(p).parent/(module.replace('.','/')+'.lean')
  require(namespace['declaration_binding'](path.read_text())==binding,'declaration binding '+module)
 manifest_summary[name]={'targets':len(current['targets']),'census':len(a['census']),'headers':sum(b['lines'] for b in a['declarations'].values())}
 if name=='determinant':
  pub=json.loads(blob(PUB,p)); require(current['compiled_inventory']==pub['compiled_inventory'],'compiled inventory')
  require(current['compiled_inventory'] is None,'null inventory')
functions=['compiled_implementation','compiled_contract','audit_compiled','invalidate_active_receipt','execute','main']
gate='frontiers/determinant_moment_20261025/gate.py'
def funcs(b): return {x.name:ast.dump(x,include_attributes=False) for x in ast.parse(b).body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))}
f,g=funcs((R/gate).read_bytes()),funcs(blob(PUB,gate))
require(all(f[n]==g[n] for n in functions),'published compiled functions')
p='frontiers/determinant_moment_20261025/compiled_inventory.py'; require((R/p).read_bytes()==blob(PUB,p),'compiled helper')
registry=json.loads((R/'tools/lean_packet_admission.registry.json').read_text())
require(all(sha((R/p).read_bytes())==h for p,h in registry['files'].items()),'registry hashes')
summary={'verified_utc':datetime.now(timezone.utc).isoformat(),'head':HEAD,'tree':commit['tree'],'changed_blobs_verified':len(commit['source_sha256']),'execution_log_hashes':len(execs),'observed_suite_discovery':counts,'mutation_log_hashes':72,'assertion_kills':kills,'full_suite_controls':controls,'positive_baselines':len(matrix),'lifecycle_observations':len(probes),'protected_bytes_verified':95,'manifests':manifest_summary,'published_compiled_functions_AST_equal':functions,'compiled_helper_byte_equal':True,'compiled_inventory':None,'registry_hashes_match':True,'test_suites_rerun':False}
(E/'review-evidence-verification.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
