from pathlib import Path
import ast,datetime,hashlib,json,subprocess
R=Path('/workspace/scratch/db6428847655/cbz/worktrees/math-composition')
O=Path(__file__).resolve().parent
BASE='f1a17bf66869d11d4b1618dd148701b6f1b2e922'
PUBLISHED='74565f013575b7b05ecfc4034cd5d638ee355353'
def need(b,m):
 if not b: raise SystemExit(m)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def prior(commit,p): return subprocess.check_output(['git','show',commit+':'+p],cwd=R)
def dump(p,x): p.write_text(json.dumps(x,indent=2)+'\n')
paths=subprocess.check_output(['git','diff','--name-only',BASE],cwd=R,text=True).splitlines()
source={p:dict(sha256=sha(R/p),mtime_utc=datetime.datetime.fromtimestamp((R/p).stat().st_mtime,datetime.timezone.utc).isoformat()) for p in paths}
reg=json.loads((R/'tools/lean_packet_admission.registry.json').read_text())
need(all(sha(R/p)==h for p,h in reg['files'].items()),'registry mismatch')
executions=json.loads((O/'execution-summary.json').read_text())
need(len(executions)==19,'execution count')
need(all(a['qualified'] and a['exit_code']==a['expected'] and sha(O/a['log'])==a['sha256'] for a in executions),'execution evidence mismatch')
need(all(x['mtime_utc']<executions[0]['started_utc'] for x in source.values()),'amended file later than final validation start')
mutations=json.loads((O/'mutations/mutation-summary.json').read_text())
need(len(mutations)==36 and len({(x['name'],x['optimized']) for x in mutations})==36,'mutation matrix shape')
need(all(x['passed'] and x['baseline']['control_pass'] and x['baseline']['collected']>0 and sha(O/'mutations'/x['log'])==x['sha256'] and sha(O/'mutations'/x['baseline']['log'])==x['baseline']['sha256'] for x in mutations),'mutation evidence mismatch')
need(sum(x['killed'] for x in mutations)==30 and sum(x['control'] and x['control_pass'] for x in mutations)==6,'mutation acceptance counts')
old={'__name__':'previous_runner','__file__':str(R/'tests/run_source_admission_mutations.py')}
exec(compile(prior(BASE,'tests/run_source_admission_mutations.py'),'previous-runner','exec'),old)
old_names={a[0] for a in old['MUTATIONS']}
new_names={a['name'] for a in mutations if not a['control']}
need(len(old_names)==14 and new_names==old_names|{'helper-declaration-header-binding-removal'},'old mutation set changed')
preservation=json.loads((O/'proof-preservation.json').read_text())
need(len(preservation['files'])==95,'protected file count')
need(all(x['byte_equal'] and sha(R/x['path'])==x['base_sha256']==x['current_sha256'] and hashlib.sha256(prior(preservation['base'],x['path'])).hexdigest()==x['base_sha256'] for x in preservation['files']),'protected file mismatch')
manifests={}
for name,path in [('determinant','frontiers/determinant_moment_20261025/manifest.json'),('cap','frontiers/cap_first_exit_lean_20261002/MANIFEST.json')]:
 current=json.loads((R/path).read_text()); before=json.loads(prior(BASE,path))
 need({k:v for k,v in before.items() if k not in ('files','source_admission')}=={k:v for k,v in current.items() if k not in ('files','source_admission')},'unintended manifest semantics '+name)
 need(before['source_admission']['census']==current['source_admission']['census'],'census changed '+name)
 need(before['source_admission']['continuations']==current['source_admission']['continuations'],'continuations changed '+name)
 need(current['source_admission']['helper_sha256']==sha(R/'tools/lean_packet_admission.py'),'helper binding mismatch '+name)
 manifests[name]={'targets':len(current['targets']), 'census':len(current['source_admission']['census']), 'census_unchanged':True,'continuations_unchanged':True,'declarations':current['source_admission']['declarations']}
p='frontiers/determinant_moment_20261025/gate.py'
funcs=['compiled_implementation','compiled_contract','audit_compiled','invalidate_active_receipt','execute','main']
def defs(data): return {x.name:ast.dump(x,include_attributes=False) for x in ast.parse(data).body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))}
a,b=defs(prior(PUBLISHED,p)),defs((R/p).read_text())
need(all(a[n]==b[n] for n in funcs),'published compiled gate changed')
p='frontiers/determinant_moment_20261025/compiled_inventory.py'
need(prior(PUBLISHED,p)==(R/p).read_bytes(),'published compiled helper changed')
phases=json.loads((O/'lifecycle-probes.json').read_text())
need(len(phases)==18,'lifecycle coverage count')
need(all((x['name']=='body_failure')==x['killed'] and (x['name']=='clean_body')==x['control_pass'] for x in phases),'lifecycle classification mismatch')
need(all('log' not in x or sha(O/x['log'])==x['sha256'] for x in phases),'lifecycle log mismatch')
result={'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'review_base':BASE,'published_compiled_base':PUBLISHED,'changed_files':source,'all_file_mtimes_precede_validation_start':True,'registry_inputs_match':True,'executions':len(executions),'execution_logs_match':True,'mutation_records':len(mutations),'mutation_log_hashes_checked':len(mutations)*2,'assertion_kills':30,'full_suite_controls':6,'positive_baselines':36,'old_mutations_preserved':sorted(old_names),'added_mutation':'helper-declaration-header-binding-removal','protected_files':95,'manifests':manifests,'published_compiled_functions_unchanged':funcs,'published_compiled_helper_unchanged':True,'lifecycle_probes':18,'actual_lean':'NOT_RUN','compiled_qualification':'UNQUALIFIED'}
dump(O/'final-evidence-verification.json',result)
print(json.dumps({k:v for k,v in result.items() if k not in ('changed_files','manifests','old_mutations_preserved')},indent=2))
