set -euo pipefail
python -B -S - <<'PYOBSERVE'
import hashlib
import json
import runpy
import shutil
gate = runpy.run_path('frontiers/determinant_moment_20261025/gate.py')
gate['invalidate_active_receipt']()
manifest, digest = gate['source_check']()
root = gate['ROOT']
helper = root / 'compiled_inventory.py'
data = helper.read_bytes()
gate['require'](not helper.is_symlink(), 'symlink compiled inventory helper')
gate['require'](hashlib.sha256(data).hexdigest() == manifest['files']['compiled_inventory.py'],
                'compiled inventory helper identity changed')
compiled = {'__name__': 'compiled_census_observation', '__file__': str(helper)}
exec(compile(data, str(helper), 'exec'), compiled)
out = root / '.lake/formal-evidence'
out.mkdir(parents=True, exist_ok=True)
run = gate['run']
gate['check_lean_version'](run(['lake', 'env', 'lean', '--version'], 'observation-version', out))
gate['dependency_state'](manifest)
build = root / '.lake/build'
if build.exists():
    shutil.rmtree(build)
run(['lake', 'build'], 'observation-build', out)
run(['lake', 'env', 'leanchecker', 'ResearchFormalCoreR1'], 'observation-leanchecker', out)
source = out / 'ObservedInventory.lean'
source.write_text(compiled['inventory_source']())
run(['lake', 'env', 'lean', str(source)], 'observation-inventory', out)
_, after = gate['source_check']()
gate['require'](after == digest, 'source identity changed during observation')
(out / 'observation-status.json').write_text(json.dumps({
    'compiled_census_observation': 'EXECUTED', 'qualification': 'UNQUALIFIED',
    'acceptance': False, 'manifest_sha256': digest,
    'compiled_helper_sha256': hashlib.sha256(data).hexdigest()}, indent=2) + '\n')
print('COMPILED_CENSUS_OBSERVED_UNQUALIFIED: raw output retained; no acceptance receipt')
PYOBSERVE
