from pathlib import Path
import subprocess, json, hashlib, datetime, time, yaml, ast
ROOT=Path('/workspace/scratch/db6428847655/cbz/worktrees/math-composition')
OUT=Path(__file__).resolve().parent
records=[]
def run(label,argv,expected=0,contains=None):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat(); t=time.monotonic()
 p=subprocess.run(argv,cwd=ROOT,capture_output=True,text=True,timeout=300)
 data=p.stdout+p.stderr; log=OUT/(label+'.log');log.write_text(data)
 qualified=p.returncode==expected and (contains is None or contains in data)
 record=dict(label=label,argv=argv,cwd=str(ROOT),started_utc=start,elapsed_seconds=round(time.monotonic()-t,3),exit_code=p.returncode,expected=expected,qualified=qualified,log=log.name,sha256=hashlib.sha256(log.read_bytes()).hexdigest())
 records.append(record); (OUT/'execution-summary.json').write_text(json.dumps(records,indent=2)+'\n')
 print(label,p.returncode,qualified,flush=True)
 if not qualified: raise SystemExit(1)
for opt in (False,True):
 mode='optimized' if opt else 'normal'; py=['python','-B']+(['-O'] if opt else [])+['-S']
 for name,directory,pattern in [('runner','tests','test_source_admission_mutations.py'),('helper','tests','test_lean_packet_admission.py'),('determinant','frontiers/determinant_moment_20261025/tests','test_*.py'),('cap','frontiers/cap_first_exit_lean_20261002','test_*.py')]:
  run(name+'-'+mode,py+['-m','unittest','discover','-s',directory,'-p',pattern,'-v'],contains='\nOK\n')
 run('source-determinant-'+mode,py+['-c',"import runpy; g=runpy.run_path('frontiers/determinant_moment_20261025/gate.py'); m,d=g['source_check'](); print('SOURCE_ONLY_IDENTITY_PASS: '+d)"],contains='SOURCE_ONLY_IDENTITY_PASS')
 run('source-cap-'+mode,py+['frontiers/cap_first_exit_lean_20261002/gate.py'],contains='source_check')
 for args,label in [([], 'diagnostic'),(['--execute'],'execute')]:
  run('cli-unqualified-'+label+'-'+mode,py+['frontiers/determinant_moment_20261025/gate.py']+args,expected=1,contains='CBZ_COMPILED_INVENTORY_UNQUALIFIED')
workflow=yaml.safe_load((ROOT/'.github/workflows/determinant-moment-lean.yml').read_text())
steps=workflow['jobs']['kernel-evidence']['steps']; checks=[]
for step in steps:
 if 'run' not in step: continue
 shell=step['run']; label='workflow-source' if step['name'].startswith('Nonzero') else 'workflow-observation' if step['name'].startswith('Observe') else None
 if not label: continue
 path=OUT/(label+'.sh');path.write_text(shell)
 run(label+'-syntax',['bash','-n',str(path)])
 if label=='workflow-observation':
  ast.parse(shell.split("<<'PYOBSERVE'\n",1)[1].rsplit('\nPYOBSERVE',1)[0]); checks.append(dict(name=label,status='PARSED_ONLY',actual_lean='NOT_RUN'))
 else:
  run(label+'-executed',['bash',str(path)],contains='SOURCE_ONLY_IDENTITY_PASS');checks.append(dict(name=label,status='EXECUTED_SOURCE_TESTS_ONLY'))
(OUT/'workflow-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
