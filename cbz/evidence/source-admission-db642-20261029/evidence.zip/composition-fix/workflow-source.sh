set -euo pipefail
for optimization in '' '-O'; do
  python -B $optimization -S - <<'PYCONTROLS'
import unittest
runner = unittest.TextTestRunner(verbosity=2)
for directory, pattern in [('tests', 'test_lean_packet_admission.py'),
                           ('tests', 'test_source_admission_mutations.py'),
                           ('frontiers/determinant_moment_20261025/tests', 'test_*.py')]:
    suite = unittest.TestLoader().discover(directory, pattern=pattern)
    if suite.countTestCases() == 0:
        raise SystemExit('zero tests discovered: ' + directory)
    if not runner.run(suite).wasSuccessful():
        raise SystemExit(1)
PYCONTROLS
done
python -B -S - <<'PYSOURCE'
import runpy
gate = runpy.run_path('frontiers/determinant_moment_20261025/gate.py')
_, digest = gate['source_check']()
print('SOURCE_ONLY_IDENTITY_PASS (no compiled or kernel qualification): ' + digest)
PYSOURCE
