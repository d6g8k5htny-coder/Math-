from pathlib import Path
import runpy,tempfile,json,subprocess
ROOT=Path('/workspace/scratch/db6428847655/cbz/worktrees/math-composition')
OUT=Path(__file__).resolve().parent
runner=runpy.run_path(str(ROOT/'tests/run_source_admission_mutations.py'))
fixtures=[
 ('setup','class Case(unittest.TestCase):\n    def setUp(self): self.fail("fixture initialization failed")\n    def test_check(self): print("BODY_ENTERED")\n',False,False),
 ('teardown','class Case(unittest.TestCase):\n    def tearDown(self): self.fail("fixture teardown failed")\n    def test_check(self): print("BODY_ENTERED")\n',False,False),
 ('cleanup','class Case(unittest.TestCase):\n    def test_check(self):\n        print("BODY_ENTERED")\n        self.addCleanup(self.fail,"fixture cleanup failed")\n',False,False),
 ('custom_teardown','class Case(unittest.TestCase):\n    def _callTearDown(self): self.fail("unsupported fixture hook")\n    def test_check(self): print("BODY_ENTERED")\n',False,False),
 ('body_error','class Case(unittest.TestCase):\n    def test_check(self): raise RuntimeError("unexpected error")\n',False,False),
 ('empty','',False,False),
 ('body_failure','class Case(unittest.TestCase):\n    def test_check(self):\n        print("BODY_ENTERED")\n        self.fail("intended body assertion")\n',False,True),
 ('clean_body','class Case(unittest.TestCase):\n    def test_check(self):\n        print("BODY_ENTERED")\n        self.assertTrue(True)\n',True,False),
]
records=[]
for optimized in (False,True):
 for name,fixture,control,kill in fixtures:
  with tempfile.TemporaryDirectory() as directory:
   root=Path(directory);(root/'test_fixture.py').write_text('import unittest\n'+fixture)
   result,observed=runner['run_process'](root,['-m','unittest','discover','-s','.', '-p','test_fixture.py','-v'],OUT,name+('-optimized' if optimized else '-normal'),optimized)
   classified=runner['classify'](result,1)
   if classified['control_pass'] != control or classified['killed'] != kill:raise SystemExit('unexpected classification: '+name)
   records.append(dict(name=name,optimized=optimized,**observed,**classified))
 with tempfile.TemporaryDirectory() as directory:
  root=Path(directory);(root/'test_fixture.py').write_text('import time,unittest\nclass Case(unittest.TestCase):\n    def test_check(self): time.sleep(1)\n')
  try:runner['run_process'](root,['-m','unittest','discover','-s','.', '-p','test_fixture.py','-v'],OUT,'timeout',optimized,timeout=.02)
  except subprocess.TimeoutExpired:records.append(dict(name='timeout',optimized=optimized,control_pass=False,killed=False,completed_result=False,exception='TimeoutExpired'))
  else:raise SystemExit('timeout fixture unexpectedly completed')
(OUT/'lifecycle-probes.json').write_text(json.dumps(records,indent=2)+'\n')
print('18 actual lifecycle/error/empty/timeout/body observations have expected classifications')
