import io,json,unittest
from pathlib import Path
namespace={}
exec(compile(Path(__file__).with_name("classifier-source.txt").read_text(), "pinned-classifier", "exec"),namespace)
seen=[]
class Fixture(unittest.TestCase):
    fail_setup=False
    def setUp(self):
        if self.fail_setup:
            self.fail("benign fixture initialization failure")
    def test_declared(self):
        seen.append("body")
        self.assertTrue(True)
baseline=unittest.TextTestRunner(stream=io.StringIO()).run(unittest.defaultTestLoader.loadTestsFromTestCase(Fixture))
seen.clear();Fixture.fail_setup=True
log=io.StringIO();result=unittest.TextTestRunner(stream=log).run(unittest.defaultTestLoader.loadTestsFromTestCase(Fixture))
accepted=True
try: namespace["require_policy_mutation_kill"](result,1,{"test_declared"})
except AssertionError: accepted=False
print(json.dumps({"baseline_pass":baseline.wasSuccessful(),"baseline_count":baseline.testsRun,"fixture_body_entered":bool(seen),"fixture_tests_run":result.testsRun,"fixture_failure_count":len(result.failures),"fixture_error_count":len(result.errors),"fixture_counted_as_kill":accepted,"transcript":log.getvalue()},indent=2))
