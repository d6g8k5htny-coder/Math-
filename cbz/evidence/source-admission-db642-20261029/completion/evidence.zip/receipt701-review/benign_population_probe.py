import io,json,unittest
from pathlib import Path
base=Path(__file__).parent;ns={}
exec(compile((base/"classifier-source.txt").read_text(),"pinned-classifier","exec"),ns)
names=json.loads((base/"population.json").read_text());chosen="test_expected_head_must_remain_stable";seen=[]
class Fixture(unittest.TestCase):
    phase=None
    def setUp(self):
        if self._testMethodName==chosen and self.phase=="setup":self.fail("benign setup assertion")
        if self._testMethodName==chosen and self.phase=="cleanup":self.addCleanup(self.fail,"benign cleanup assertion")
    def tearDown(self):
        if self._testMethodName==chosen and self.phase=="teardown":self.fail("benign teardown assertion")
def body(self):seen.append(self._testMethodName);self.assertTrue(True)
for name in names:setattr(Fixture,name,body)
loader=unittest.TestLoader();baseline=unittest.TextTestRunner(stream=io.StringIO()).run(loader.loadTestsFromTestCase(Fixture));records=[]
for phase in ("setup","teardown","cleanup"):
    seen.clear();Fixture.phase=phase;log=io.StringIO();result=unittest.TextTestRunner(stream=log).run(loader.loadTestsFromTestCase(Fixture));accepted=True
    try:ns["require_policy_mutation_kill"](result,len(names),{chosen})
    except AssertionError:accepted=False
    records.append({"phase":phase,"expected_population":len(names),"observed_population":result.testsRun,"bodies_entered":len(seen),"chosen_body_entered":chosen in seen,"failures":[test.id().rsplit(".",1)[-1] for test,_ in result.failures],"errors":len(result.errors),"skips":len(result.skipped),"counted_as_kill":accepted,"transcript":log.getvalue()})
print(json.dumps({"baseline_pass":baseline.wasSuccessful(),"baseline_count":baseline.testsRun,"observations":records},indent=2))
