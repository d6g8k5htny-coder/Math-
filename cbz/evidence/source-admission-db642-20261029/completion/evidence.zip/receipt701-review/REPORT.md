# Scoped Main701 mutation lifecycle finding

Source: 7b1657700aca5f8e9c391513c7974009688945ab, tests/test_formal_compiled_inventory.py:326.

The exact predicate accepted real unittest setup, teardown and cleanup assertion failures with the22 named custody methods, matching declared singleton failure, no errors/skips and a clean22-case baseline. In the setup case only21 bodies ran and the declared body never entered. Both Python modes behaved identically. This is a classifier contract defect, not a retraction of earlier observed actual mutations or kernel results.

Preserved source pin/fragment: SOURCE.json and classifier-source.txt. Benign actual fixtures: benign_population_probe.py; population-normal.json and population-optimized.json contain full transcripts. The simpler one-case initial probe is also retained. No repository source or remote branch changed. Proposed minimal correction reuses the reviewed Math lifecycle pattern while retaining full-population and exact-name requirements.

Observed report time: 2026-10-29T19:30:00.479619+00:00
