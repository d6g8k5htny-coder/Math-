import copy
import hashlib
import importlib.util
import json
import contextlib
import io
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('gate', ROOT / 'gate.py')
gate = importlib.util.module_from_spec(spec) if spec else None
if spec and spec.loader and (ROOT / 'gate.py').exists():
    spec.loader.exec_module(gate)

class GateTests(unittest.TestCase):
    def setUp(self):
        self.assertTrue(hasattr(gate, 'audit_axioms'), 'formal evidence gate not implemented')

    def test_standard_axioms(self):
        self.assertEqual(gate.audit_axioms("'X.a' depends on axioms: [propext, Classical.choice, Quot.sound]", ['X.a'])['X.a'], ['Classical.choice', 'Quot.sound', 'propext'])
    def test_axiom_free(self):
        self.assertEqual(gate.audit_axioms("'X.a' does not depend on any axioms", ['X.a']), {'X.a': []})
    def test_sorry(self):
        with self.assertRaises(ValueError): gate.audit_axioms("'X.a' depends on axioms: [sorryAx]", ['X.a'])
    def test_custom(self):
        with self.assertRaises(ValueError): gate.audit_axioms("'X.a' depends on axioms: [Other.hidden]", ['X.a'])
    def test_native(self):
        with self.assertRaises(ValueError): gate.audit_axioms("'X.a' depends on axioms: [X.a._nativeDecide_1]", ['X.a'])
    def test_missing_target(self):
        with self.assertRaises(ValueError): gate.audit_axioms('', ['X.a'])
    def test_duplicate_target_output(self):
        with self.assertRaises(ValueError): gate.audit_axioms("'X.a' does not depend on any axioms\n'X.a' does not depend on any axioms", ['X.a'])
    def test_duplicate_target_request(self):
        with self.assertRaises(ValueError): gate.audit_axioms("'X.a' does not depend on any axioms", ['X.a','X.a'])
    def test_unexpected_target(self):
        with self.assertRaises(ValueError): gate.audit_axioms("'X.b' does not depend on any axioms", ['X.a'])
    def test_multiline(self):
        self.assertIn('X.a', gate.audit_axioms("'X.a' depends on axioms: [propext,\n Classical.choice]", ['X.a']))
    def test_noise_denied(self):
        with self.assertRaises(ValueError): gate.audit_axioms("error: bad\n'X.a' does not depend on any axioms", ['X.a'])
    def test_manifest_content(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d); (p/'x').write_bytes(b'abc')
            self.assertEqual(gate.check_files(p, {'x':hashlib.sha256(b'abc').hexdigest()}), None)
    def test_manifest_tamper(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d); (p/'x').write_bytes(b'bad')
            with self.assertRaises(ValueError): gate.check_files(p, {'x':hashlib.sha256(b'abc').hexdigest()})
    def test_manifest_missing(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError): gate.check_files(Path(d), {'missing':'0'*64})
    def test_manifest_escape(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError): gate.check_files(Path(d), {'../x':'0'*64})
    def test_manifest_absolute(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError): gate.check_files(Path(d), {'/x':'0'*64})
    def test_manifest_symlink(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d); (p/'x').write_bytes(b'a'); (p/'y').symlink_to(p/'x')
            with self.assertRaises(ValueError): gate.check_files(p, {'y':hashlib.sha256(b'a').hexdigest()})
    def test_manifest_empty(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError): gate.check_files(Path(d), {})
    def review(self):
        return dict(disposition='ACCEPTED',manifest_sha256='a'*64,targets=['X.a'],scope_sha256='b'*64,
                    author={'provider':'OpenAI','family':'GPT','agent':'A'},reviewer={'provider':'Other','family':'Different','agent':'B'},
                    evidence={'repository':'o/r','commit':'c'*40,'path':'review.md','sha256':'d'*64})
    def test_review_valid(self):
        gate.check_alignment(self.review(), 'a'*64, ['X.a'], 'b'*64)
    def test_review_stale(self):
        with self.assertRaises(ValueError): gate.check_alignment(self.review(), 'e'*64, ['X.a'], 'b'*64)
    def test_review_self(self):
        r=self.review(); r['reviewer']=r['author'].copy()
        with self.assertRaises(ValueError): gate.check_alignment(r, 'a'*64, ['X.a'], 'b'*64)
    def test_review_same_provider(self):
        r=self.review(); r['reviewer']['provider']='OpenAI'
        with self.assertRaises(ValueError): gate.check_alignment(r, 'a'*64, ['X.a'], 'b'*64)
    def test_review_partial(self):
        with self.assertRaises(ValueError): gate.check_alignment(self.review(), 'a'*64, ['X.a','X.b'], 'b'*64)
    def test_review_bad_disposition(self):
        r=self.review(); r['disposition']='AMEND_REQUIRED'
        with self.assertRaises(ValueError): gate.check_alignment(r, 'a'*64, ['X.a'], 'b'*64)
    def test_review_bad_evidence(self):
        r=self.review(); r['evidence']['commit']='main'
        with self.assertRaises(ValueError): gate.check_alignment(r, 'a'*64, ['X.a'], 'b'*64)
    def test_review_changed_scope(self):
        with self.assertRaises(ValueError): gate.check_alignment(self.review(), 'a'*64, ['X.a'], 'c'*64)

class BlueprintTests(unittest.TestCase):
    def test_valid_link(self):
        self.assertEqual(gate.check_blueprint(r'\lean{X.a}', ['X.a']), ['X.a'])
    def test_wrong_link(self):
        with self.assertRaises(ValueError): gate.check_blueprint(r'\lean{X.b}', ['X.a'])
    def test_empty_link(self):
        with self.assertRaises(ValueError): gate.check_blueprint('', ['X.a'])
    def test_unsupported_leanok(self):
        with self.assertRaises(ValueError): gate.check_blueprint(r'\lean{X.a}\leanok', ['X.a'])

class SourceContractTests(unittest.TestCase):
    def fixture(self):
        import shutil
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        p = Path(self.tmp.name) / 'formal'
        shutil.copytree(ROOT, p, ignore=shutil.ignore_patterns('.lake', '__pycache__'))
        self.previous = gate.ROOT; gate.ROOT = p
        self.addCleanup(lambda: setattr(gate, 'ROOT', self.previous))
        self.m = json.loads((p/'manifest.json').read_text())
        self.m['files'] = {q.relative_to(p).as_posix(): hashlib.sha256(q.read_bytes()).hexdigest() for q in p.rglob('*') if q.is_file() and q.name != 'manifest.json'}
        self.p = p
        return p
    def save(self):
        (self.p/'manifest.json').write_text(json.dumps(self.m))
    def test_source_baseline(self):
        self.fixture(); self.save(); gate.source_check()
    def test_unbound_gate_refused(self):
        self.fixture(); del self.m['files']['gate.py']; self.save()
        with self.assertRaises(ValueError): gate.source_check()
    def test_manifest_cannot_claim_kernel_status(self):
        self.fixture(); self.m['formalization_status']='kernel-checked'; self.save()
        with self.assertRaises(ValueError): gate.source_check()
    def test_root_declaration_cannot_evade_audit(self):
        p=self.fixture(); root=p/'ResearchFormalCoreR1.lean'
        root.write_text(root.read_text()+'theorem hidden : False := by sorry\n')
        self.m['files']['ResearchFormalCoreR1.lean']=hashlib.sha256(root.read_bytes()).hexdigest(); self.save()
        with self.assertRaises(ValueError): gate.source_check()
    def test_duplicate_json_rejected(self):
        with self.assertRaises(ValueError): gate.load_json('{"a":1,"a":2}')
    def test_json_object(self):
        self.assertEqual(gate.load_json('{"a":1}'), {'a':1})

class RuntimeVersionTests(unittest.TestCase):
    # These are orchestration tests with synthetic external process results;
    # source validation, log writes, build deletion and receipts are real.
    RELEASE = 'Lean (version 4.34.1, x86_64-unknown-linux-gnu, commit 5045d0056413266e57c625dcd7c365b10e377c52, Release)'

    def fixture(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.root = Path(tmp.name) / 'formal'
        shutil.copytree(ROOT, self.root, ignore=shutil.ignore_patterns('.lake', '__pycache__'))
        previous = gate.ROOT
        gate.ROOT = self.root
        self.addCleanup(lambda: setattr(gate, 'ROOT', previous))
        manifest_path = self.root / 'manifest.json'
        manifest = json.loads(manifest_path.read_text())
        # Synthetic external-process orchestration fixture only. This is not an
        # observed inventory of the real determinant package.
        manifest['compiled_inventory'] = []
        manifest.pop('compiled_inventory_version', None)  # Legacy strict synthetic protocol, not actual package census.
        manifest['files'] = {p.relative_to(self.root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                             for p in self.root.rglob('*') if p.is_file() and p.name != 'manifest.json'}
        manifest_path.write_text(json.dumps(manifest))
        self.manifest, self.digest = gate.source_check()
        self.sentinel = self.root / '.lake/build/preserve-before-preflight'
        self.sentinel.parent.mkdir(parents=True)
        self.sentinel.write_text('old build')
        self.calls = []
        self.version_index = 0

    def synthetic_inventory(self, cwd, fault=None):
        """Explicit synthetic protocol boundary, never actual Lean evidence."""
        paths = self.manifest['source_modules']
        module = tuple(paths[0][:-5].replace('/', '.').split('.'))
        rows = [('theorem', 'user', module, tuple(n.split('.'))) for n in self.manifest['targets']]
        axs = []
        source = (cwd / paths[0]).read_text()
        if fault == 'empty':
            return ''
        if fault == 'unlisted':
            rows.append(('theorem', 'user', module, ('ResearchFormalCoreR1', 'hiddenIndented')))
            axs = [('sorryAx',)]
        elif 'private theorem compiledAdmission' in source:
            rows.append(('theorem', 'user', module,
                         ('_private',) + module + (0, 'ResearchFormalCoreR1', 'compiledAdmission')))
            axs = [('sorryAx',)]
        elif 'Lean.addDecl' in source:
            rows.append(('theorem', 'aux', module, ('ResearchFormalCoreR1', 'ec005_fold_gap', '_proof_999')))
        def enc(name):
            return '/'.join('n' + str(c) if isinstance(c, int) else 's' + c.encode().hex() for c in name)
        text = ['MODULE|' + enc(('ResearchFormalCoreR1',)) + '|false|0|0']
        for path in paths:
            m = tuple(path[:-5].replace('/', '.').split('.'))
            text.append('MODULE|' + enc(m) + '|false|' + str(sum(r[2] == m for r in rows)) + '|0')
        text += ['INV|' + k + '|' + o + '|' + enc(m) + '|' + enc(n) for k, o, m, n in rows]
        return '\n'.join(text + ['AXIOMS|' + ','.join(enc(a) for a in axs),
                                 'CLOSURE|' + str(len(rows) + 1)])

    def execute_synthetic(self, versions, version_exit=0, mutate_source=False, wrong_dependency=False,
                          dirty_dependency=None, drift_dependency=False, env=None, inventory_fault=None):
        def external_run(command, **kwargs):
            self.calls.append(command)
            if command == ['lake', 'build']:
                (Path(kwargs['cwd']) / '.lake/build').mkdir(parents=True, exist_ok=True)
            if command == ['lake', 'env', 'lean', '--version']:
                text = versions[min(self.version_index, len(versions) - 1)] + '\n'
                self.version_index += 1
                return subprocess.CompletedProcess(command, version_exit, text)
            if command == ['lake', 'build'] and mutate_source:
                path = self.root / 'lake-manifest.json'
                path.write_bytes(path.read_bytes() + b'\n')
            label = Path(command[-1]).stem
            if label == 'Audit':
                text = '\n'.join("'" + n + "' does not depend on any axioms" for n in self.manifest['targets'])
            elif label == 'Inventory':
                cwd = Path(kwargs['cwd'])
                text = self.synthetic_inventory(cwd, inventory_fault if cwd == self.root else None)
            elif label in ('false_fold', 'false_power'):
                return subprocess.CompletedProcess(command, 1, 'unsolved goals\n')
            elif label in ('sorry', 'custom_imported', 'native'):
                forbidden = {'sorry': 'sorryAx', 'custom_imported': 'hiddenPremise', 'native': 'injected._nativeDecide_1'}[label]
                text = "'injected' depends on axioms: [" + forbidden + ']'
            else:
                text = ''
            return subprocess.CompletedProcess(command, 0, text)

        def external_git(command, **kwargs):
            if command == ['git', 'rev-parse', 'HEAD']:
                return 'b' * 40 + '\n'
            name = Path(command[2]).name
            final_phase = self.version_index >= 2  # after the final version observation
            if command[3:] == ['status', '--porcelain', '--untracked-files=normal']:
                dirty = dirty_dependency == 'preflight' and not final_phase or dirty_dependency == 'final' and final_phase
                return ' M Mathlib/Injected.lean\n' if dirty else ''
            revision = self.manifest['dependency_revisions'][name]
            return ('c' * 40 if wrong_dependency or drift_dependency and final_phase else revision) + '\n'

        with patch.object(gate.subprocess, 'run', side_effect=external_run), \
             patch.object(gate.subprocess, 'check_output', side_effect=external_git), \
             patch.dict(gate.os.environ, env or {}), \
             contextlib.redirect_stdout(io.StringIO()):
            return gate.execute(self.manifest, self.digest)

    def assert_no_receipt(self):
        self.assertFalse((self.root / '.lake/formal-evidence/receipt.json').exists())

    def test_complete_pinned_release_record(self):
        self.assertTrue(callable(getattr(gate, 'check_lean_version', None)), 'complete release validator missing')
        self.assertEqual(gate.check_lean_version(self.RELEASE + '\n'), self.RELEASE)

    def test_other_versions_and_incomplete_or_extra_records_refused(self):
        self.assertTrue(callable(getattr(gate, 'check_lean_version', None)), 'complete release validator missing')
        invalid = ['', 'unrelated version 4.34.1 text',
                   self.RELEASE.replace('4.34.1', '4.34.10'), self.RELEASE.replace('4.34.1', '4.34.100'),
                   self.RELEASE.replace('4.34.1', '4.34.1-rc1'), self.RELEASE.replace('4.34.1', '4.34.1-nightly'),
                   'Lean (version 4.34.1,', self.RELEASE.replace(', Release)', ', Debug)'),
                   'noise\n' + self.RELEASE, self.RELEASE + '\nnoise', self.RELEASE + '\n' + self.RELEASE]
        for text in invalid:
            with self.subTest(text=text), self.assertRaisesRegex(ValueError, 'unexpected running Lean version'):
                gate.check_lean_version(text)

    def test_short_and_other_release_commits_refused(self):
        # A release label cannot authenticate a truncated or different compiler.
        for commit in ('a', '5045d005', '0' * 40, 'f' * 40):
            text = 'Lean (version 4.34.1, x86_64-unknown-linux-gnu, commit ' + commit + ', Release)'
            with self.subTest(commit=commit), self.assertRaisesRegex(ValueError, 'unexpected running Lean version'):
                gate.check_lean_version(text)

    def test_other_commit_preflight_preserves_build(self):
        self.fixture()
        wrong = 'Lean (version 4.34.1, x86_64-unknown-linux-gnu, commit ' + '0' * 40 + ', Release)'
        with self.assertRaisesRegex(ValueError, 'unexpected running Lean version'):
            self.execute_synthetic([wrong])
        self.assertEqual(self.sentinel.read_bytes(), b'old build')
        self.assertEqual(self.calls, [['lake', 'env', 'lean', '--version']])
        self.assert_no_receipt()

    def test_other_commit_after_execution_refuses_receipt(self):
        self.fixture()
        wrong = 'Lean (version 4.34.1, x86_64-unknown-linux-gnu, commit ' + 'f' * 40 + ', Release)'
        with self.assertRaisesRegex(ValueError, 'unexpected running Lean version'):
            self.execute_synthetic([self.RELEASE, wrong])
        self.assertEqual(self.version_index, 2)
        self.assertFalse(self.sentinel.exists())
        self.assert_no_receipt()

    def test_invalid_preflight_preserves_build_and_runs_no_build(self):
        self.fixture()
        with self.assertRaisesRegex(ValueError, 'unexpected running Lean version'):
            self.execute_synthetic([self.RELEASE.replace('4.34.1', '4.34.10')])
        self.assertTrue(self.sentinel.exists(), 'preflight refusal deleted the old build')
        self.assertEqual(self.calls, [['lake', 'env', 'lean', '--version']])
        self.assert_no_receipt()

    def test_preflight_process_failure_preserves_build(self):
        self.fixture()
        with self.assertRaisesRegex(ValueError, 'unexpected process outcome'):
            self.execute_synthetic([self.RELEASE], version_exit=1)
        self.assertTrue(self.sentinel.exists(), 'failed preflight deleted the old build')
        self.assertEqual(self.calls, [['lake', 'env', 'lean', '--version']])
        self.assert_no_receipt()

    def test_success_checks_before_build_and_after_controls_and_binds_both_logs(self):
        self.fixture()
        receipt = self.execute_synthetic([self.RELEASE, self.RELEASE])
        self.assertEqual(self.calls[0], ['lake', 'env', 'lean', '--version'])
        self.assertEqual(self.calls[1], ['lake', 'build'])
        self.assertEqual(self.calls[-1], ['lake', 'env', 'lean', '--version'])
        self.assertEqual(self.version_index, 2)
        self.assertFalse(self.sentinel.exists())
        self.assertEqual(receipt['lean_version'], self.RELEASE)
        self.assertEqual(receipt['manifest_sha256'], self.digest)
        self.assertEqual(receipt['checked_commit'], 'b' * 40)  # synthetic Git result
        self.assertEqual(set(receipt['negative_controls']), {'false_fold', 'false_power', 'sorry', 'custom_imported', 'native'})
        out = self.root / '.lake/formal-evidence'
        self.assertEqual(set(receipt['logs']), {p.name for p in out.glob('*.log')})
        for name in ('version-preflight.log', 'version.log'):
            self.assertEqual(receipt['logs'][name], hashlib.sha256((out / name).read_bytes()).hexdigest())

    def test_version_change_after_execution_refuses_receipt(self):
        self.fixture()
        with self.assertRaisesRegex(ValueError, 'unexpected running Lean version'):
            self.execute_synthetic([self.RELEASE, self.RELEASE.replace('4.34.1', '4.34.10')])
        self.assertEqual(self.version_index, 2)
        self.assert_no_receipt()

    def test_source_change_during_build_still_refuses_receipt(self):
        self.fixture()
        with self.assertRaisesRegex(ValueError, 'source hash mismatch: lake-manifest.json'):
            self.execute_synthetic([self.RELEASE], mutate_source=True)
        self.assert_no_receipt()

    def test_installed_dependency_change_still_refuses_receipt(self):
        self.fixture()
        with self.assertRaisesRegex(ValueError, 'installed dependency HEAD differs from lock'):
            self.execute_synthetic([self.RELEASE], wrong_dependency=True)
        self.assert_no_receipt()

class RuntimeGuardTests(unittest.TestCase):
    synthetic_inventory = RuntimeVersionTests.synthetic_inventory
    # The uniform runtime guard: the exact release, locked and clean dependencies and the bound
    # sources are observed before the first Lean execution and again after the last one, and the
    # two observations must be equal. These controls fail on a gate that checks only versions.
    # Reuses the synthetic-process harness above without re-running its tests.
    RELEASE = RuntimeVersionTests.RELEASE
    OTHER_PLATFORM = RELEASE.replace('x86_64-unknown-linux-gnu', 'aarch64-unknown-linux-gnu')
    fixture = RuntimeVersionTests.fixture
    execute_synthetic = RuntimeVersionTests.execute_synthetic
    assert_no_receipt = RuntimeVersionTests.assert_no_receipt

    def test_green_public_targets_do_not_hide_bad_compiled_inventory(self):
        self.fixture()
        with self.assertRaisesRegex(ValueError, 'extra_theorem|forbidden_axiom'):
            self.execute_synthetic([self.RELEASE, self.RELEASE], inventory_fault='unlisted')
        self.assert_no_receipt()

    def test_missing_compiled_output_refuses_receipt(self):
        self.fixture()
        with self.assertRaisesRegex(ValueError, 'empty environment inventory'):
            self.execute_synthetic([self.RELEASE, self.RELEASE], inventory_fault='empty')
        self.assert_no_receipt()

    def test_dirty_dependency_before_execution_refuses_and_preserves_build(self):
        self.fixture()
        with self.assertRaisesRegex(ValueError, 'dependency worktree is not clean'):
            self.execute_synthetic([self.RELEASE, self.RELEASE], dirty_dependency='preflight')
        self.assertEqual(self.calls, [['lake', 'env', 'lean', '--version']])
        self.assertTrue(self.sentinel.exists(), 'preflight refusal deleted the old build')
        self.assert_no_receipt()

    def test_wrong_dependency_before_execution_refuses_and_preserves_build(self):
        self.fixture()
        with self.assertRaisesRegex(ValueError, 'installed dependency HEAD differs from lock'):
            self.execute_synthetic([self.RELEASE, self.RELEASE], wrong_dependency=True)
        self.assertEqual(self.calls, [['lake', 'env', 'lean', '--version']])
        self.assertTrue(self.sentinel.exists(), 'preflight refusal deleted the old build')
        self.assert_no_receipt()

    def test_dependency_dirtied_during_execution_refuses_receipt(self):
        self.fixture()
        with self.assertRaisesRegex(ValueError, 'dependency worktree is not clean'):
            self.execute_synthetic([self.RELEASE, self.RELEASE], dirty_dependency='final')
        self.assertEqual(self.version_index, 2)
        self.assert_no_receipt()

    def test_dependency_moved_during_execution_refuses_receipt(self):
        self.fixture()
        with self.assertRaisesRegex(ValueError, 'installed dependency HEAD differs from lock'):
            self.execute_synthetic([self.RELEASE, self.RELEASE], drift_dependency=True)
        self.assertEqual(self.version_index, 2)
        self.assert_no_receipt()

    def test_runtime_changed_between_observations_refuses_receipt(self):
        # Both lines are well-formed records of the pinned release; only the platform differs.
        self.fixture()
        self.assertEqual(gate.check_lean_version(self.OTHER_PLATFORM), self.OTHER_PLATFORM)
        with self.assertRaisesRegex(ValueError, 'changed during execution'):
            self.execute_synthetic([self.RELEASE, self.OTHER_PLATFORM])
        self.assert_no_receipt()

    def test_receipt_binds_attempt_and_both_equal_observations(self):
        self.fixture()
        receipt = self.execute_synthetic([self.RELEASE, self.RELEASE],
                                         env={'GITHUB_RUN_ID': '12345', 'GITHUB_RUN_ATTEMPT': '2'})
        self.assertEqual(receipt['workflow_run_id'], '12345')
        self.assertEqual(receipt['workflow_run_attempt'], '2')
        self.assertEqual(receipt['dependency_worktrees'], 'CLEAN')
        expected = {'lean_version': self.RELEASE, 'dependency_revisions': self.manifest['dependency_revisions'],
                    'dependency_worktrees': 'CLEAN', 'manifest_sha256': self.digest}
        self.assertEqual(receipt['observations'], {'preflight': expected, 'final': expected})
        written = json.loads((self.root / '.lake/formal-evidence/receipt.json').read_text())
        self.assertEqual(written['observations'], receipt['observations'])

class SuccessorTests(unittest.TestCase):
    def test_only_documented_algebra_repairs(self):
        original=(ROOT/'originals/Algebra.lean.txt').read_text()
        expected=original.replace('def foldPotential', 'noncomputable def foldPotential').replace('  field_simp [hr]\n  ring\n', '  field_simp [hr]\n')
        self.assertEqual((ROOT/'ResearchFormalCoreR1/AlgebraV2.lean').read_text(), expected.replace("import Mathlib\n", 'import Mathlib.Basic.Real.Basic\nimport Mathlib.Tactic.FieldSimp\nimport Mathlib.Tactic.Ring\nimport Mathlib.Tactic.NormNum\n'))
    def test_only_documented_probability_repair(self):
        original=(ROOT/'originals/ProbabilityCompanions.lean.txt').read_text()
        expected=original.replace('  field_simp [hr, hcZ]\n  ring\n', '  field_simp [hr, hcZ]\n')
        self.assertEqual((ROOT/'ResearchFormalCoreR1/ProbabilityCompanionsV2.lean').read_text(), expected.replace("import Mathlib\n", 'import Mathlib.Analysis.Real.Sqrt\nimport Mathlib.Tactic.FieldSimp\nimport Mathlib.Tactic.Ring\nimport Mathlib.Tactic.NormNum\nimport Mathlib.Tactic.Positivity\nimport Mathlib.Tactic.Linarith\n'))

class SourceAdmissionTests(unittest.TestCase):
    def test_declaration_header_bindings_missing_malformed_or_changed_rejected(self):
        module = 'ResearchFormalCoreR1.AlgebraV2'
        for bad in [None, {}, [], {module: None}, {module: {}}, {module: {'sha256': '0' * 64, 'lines': 1}}]:
            with self.subTest(bindings=bad), tempfile.TemporaryDirectory() as d:
                packet = Path(d) / 'packet'
                shutil.copytree(ROOT, packet, ignore=shutil.ignore_patterns('.lake', '__pycache__'))
                m = json.loads((packet / 'manifest.json').read_text())
                if isinstance(bad, dict) and module in bad:
                    m['source_admission']['declarations'][module] = bad[module]
                else:
                    m['source_admission']['declarations'] = bad
                for name in m['files']:
                    m['files'][name] = hashlib.sha256((packet / name).read_bytes()).hexdigest()
                (packet / 'manifest.json').write_text(json.dumps(m))
                with patch.object(gate, 'ROOT', packet), self.assertRaisesRegex(ValueError, 'source declaration header'):
                    gate.source_check()

    def test_rebound_one_line_declaration_tail_rejected(self):
        anchor = 'noncomputable def foldPotential (s x : ℝ) : ℝ := -(x ^ 3) / 3 + (s ^ 2) * x'
        for tail in [' register_option cbzHidden : Bool := { defValue := false, descr := "review" }',
                     ' newUnknownCommand cbz', ' (unreviewed : Nat)']:
            with self.subTest(tail=tail), tempfile.TemporaryDirectory() as d:
                packet = Path(d) / 'packet'
                shutil.copytree(ROOT, packet, ignore=shutil.ignore_patterns('.lake', '__pycache__'))
                path = packet / 'ResearchFormalCoreR1/AlgebraV2.lean'
                original = path.read_text()
                self.assertEqual(original.count(anchor), 1)
                path.write_text(original.replace(anchor, anchor + tail))
                m = json.loads((packet / 'manifest.json').read_text())
                for name in m['files']:
                    m['files'][name] = hashlib.sha256((packet / name).read_bytes()).hexdigest()
                (packet / 'manifest.json').write_text(json.dumps(m))
                with patch.object(gate, 'ROOT', packet), self.assertRaisesRegex(ValueError, 'unsupported changed source declaration header binding'):
                    gate.source_check()

    def test_commented_fake_declaration_does_not_change_census_or_targets(self):
        with tempfile.TemporaryDirectory() as d:
            packet = Path(d) / 'packet'
            shutil.copytree(ROOT, packet, ignore=shutil.ignore_patterns('.lake', '__pycache__'))
            path = packet / 'ResearchFormalCoreR1/AlgebraV2.lean'
            path.write_text(path.read_text() + '\n/-\ntheorem cbzComment : False := by sorry\n-/\n')
            m = json.loads((packet / 'manifest.json').read_text())
            for name in m['files']:
                m['files'][name] = hashlib.sha256((packet / name).read_bytes()).hexdigest()
            (packet / 'manifest.json').write_text(json.dumps(m))
            with patch.object(gate, 'ROOT', packet):
                gate.source_check()

    def test_malformed_or_stale_census_rejected_after_hash_rebind(self):
        for bad in [None, {}, [], ['bad'], [{'module': 'X'}]]:
            with self.subTest(census=bad), tempfile.TemporaryDirectory() as d:
                packet = Path(d) / 'packet'
                shutil.copytree(ROOT, packet, ignore=shutil.ignore_patterns('.lake', '__pycache__'))
                m = json.loads((packet / 'manifest.json').read_text())
                m['source_admission']['census'] = bad
                for name in m['files']:
                    m['files'][name] = hashlib.sha256((packet / name).read_bytes()).hexdigest()
                (packet / 'manifest.json').write_text(json.dumps(m))
                with patch.object(gate, 'ROOT', packet), self.assertRaisesRegex(ValueError, 'source declaration census'):
                    gate.source_check()

    def test_continuation_inventory_missing_malformed_or_changed_rejected(self):
        module = 'ResearchFormalCoreR1.AlgebraV2'
        for bad in [None, {}, [], {module: None}, {module: {}}, {module: {'sha256': '0' * 64, 'lines': 1}}]:
            with self.subTest(bindings=bad), tempfile.TemporaryDirectory() as d:
                packet = Path(d) / 'packet'
                shutil.copytree(ROOT, packet, ignore=shutil.ignore_patterns('.lake', '__pycache__'))
                m = json.loads((packet / 'manifest.json').read_text())
                if isinstance(bad, dict) and module in bad:
                    m['source_admission']['continuations'][module] = bad[module]
                else:
                    m['source_admission']['continuations'] = bad
                for name in m['files']:
                    m['files'][name] = hashlib.sha256((packet / name).read_bytes()).hexdigest()
                (packet / 'manifest.json').write_text(json.dumps(m))
                with patch.object(gate, 'ROOT', packet), self.assertRaisesRegex(ValueError, 'source continuation'):
                    gate.source_check()

    def test_placeholder_refused_even_with_rebound_continuation_binding(self):
        with tempfile.TemporaryDirectory() as d:
            packet = Path(d) / 'packet'
            shutil.copytree(ROOT, packet, ignore=shutil.ignore_patterns('.lake', '__pycache__'))
            path = packet / 'ResearchFormalCoreR1/AlgebraV2.lean'
            path.write_text(path.read_text().replace(':= by\n', ':= by\n  have cbzUnused : False := sorryAx False true\n', 1))
            m = json.loads((packet / 'manifest.json').read_text())
            admission = gate.load_admission(gate.REPO, m['source_admission'])
            m['source_admission']['continuations']['ResearchFormalCoreR1.AlgebraV2'] = admission['continuation_binding'](path.read_text())
            for name in m['files']:
                m['files'][name] = hashlib.sha256((packet / name).read_bytes()).hexdigest()
            (packet / 'manifest.json').write_text(json.dumps(m))
            with patch.object(gate, 'ROOT', packet), self.assertRaisesRegex(ValueError, 'forbidden token'):
                gate.source_check()

    def test_rebound_unknown_continuation_and_direct_placeholder_rejected(self):
        for command, reason in [
            ('newUnknownCommand cbz', 'unsupported.*continuation'),
            ('register_option cbzHidden : Bool := { defValue := false, descr := "review" }', 'unsupported.*continuation'),
            ('have cbzUnused : False := sorryAx False true', 'forbidden token'),
            ('have cbzUnused : False := _root_.sorryAx False true', 'forbidden token'),
        ]:
            for location in ['after_namespace', 'between_declarations', 'existing_proof']:
                with self.subTest(command=command, location=location), tempfile.TemporaryDirectory() as d:
                    packet = Path(d) / 'packet'
                    shutil.copytree(ROOT, packet, ignore=shutil.ignore_patterns('.lake', '__pycache__'))
                    path = packet / 'ResearchFormalCoreR1/AlgebraV2.lean'
                    text = path.read_text()
                    insertion = '  ' + command + '\n'
                    if location == 'after_namespace':
                        text += '\n' + insertion
                    elif location == 'between_declarations':
                        text = text.replace('theorem ec008_factor_expansion', insertion + '\ntheorem ec008_factor_expansion', 1)
                    else:
                        text = text.replace(':= by\n', ':= by\n' + insertion, 1)
                    path.write_text(text)
                    m = json.loads((packet / 'manifest.json').read_text())
                    for name in m['files']:
                        m['files'][name] = hashlib.sha256((packet / name).read_bytes()).hexdigest()
                    (packet / 'manifest.json').write_text(json.dumps(m))
                    with patch.object(gate, 'ROOT', packet), self.assertRaisesRegex(ValueError, reason):
                        gate.source_check()

    def test_digest_rebound_omitted_declarations_rejected(self):
        cases = [
            ('private theorem cbzPrivate : True := by trivial', 'source declaration census mismatch'),
            ('  theorem cbzIndented : True := by trivial', 'unsupported declaration spelling'),
            ('@[simp] theorem cbzAttributed : True := by trivial', 'unsupported'),
            ('axiom cbzAxiom : False', 'forbidden token'),
            ('noncomputable def cbzSorry : False := by sorry', 'forbidden token'),
            ('theorem cbzNative : True := by native_decide', 'forbidden token'),
        ]
        for insertion, reason in cases:
            with self.subTest(insertion=insertion), tempfile.TemporaryDirectory() as d:
                packet = Path(d) / 'packet'
                shutil.copytree(ROOT, packet, ignore=shutil.ignore_patterns('.lake', '__pycache__'))
                path = packet / 'ResearchFormalCoreR1/AlgebraV2.lean'
                path.write_text(path.read_text().replace('end ResearchFormalCoreR1', insertion + '\nend ResearchFormalCoreR1'))
                m = json.loads((packet / 'manifest.json').read_text())
                if reason == 'source declaration census mismatch':
                    admission = gate.load_admission(gate.REPO, m['source_admission'])
                    m['source_admission']['declarations']['ResearchFormalCoreR1.AlgebraV2'] = admission['declaration_binding'](path.read_text())
                for name in m['files']:
                    m['files'][name] = hashlib.sha256((packet / name).read_bytes()).hexdigest()
                (packet / 'manifest.json').write_text(json.dumps(m))
                with patch.object(gate, 'ROOT', packet), self.assertRaisesRegex(ValueError, reason):
                    gate.source_check()

if __name__ == '__main__': unittest.main()
